#!/usr/bin/env bash
set -euo pipefail
if command -v apt-get >/dev/null 2>&1; then
  sudo apt-get update
  sudo apt-get install -y libssl3 libstdc++6 zlib1g libzstd1
elif command -v dnf >/dev/null 2>&1; then
  sudo dnf install -y openssl-libs libstdc++ zlib zstd-libs
elif command -v pacman >/dev/null 2>&1; then
  sudo pacman -Sy --needed openssl gcc-libs zlib zstd
else
  echo "Unsupported package manager. Install runtime libraries manually: OpenSSL 3, libstdc++, zlib, zstd." >&2
  exit 2
fi
