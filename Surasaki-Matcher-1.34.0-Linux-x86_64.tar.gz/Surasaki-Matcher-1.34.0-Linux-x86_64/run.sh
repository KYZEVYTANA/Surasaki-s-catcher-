#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
BIN="$ROOT/bin/surasaki-matcher"
if [[ ! -x "$BIN" ]]; then
  echo "ERROR: executable not found: $BIN" >&2
  exit 1
fi
exec "$BIN" "$@"
