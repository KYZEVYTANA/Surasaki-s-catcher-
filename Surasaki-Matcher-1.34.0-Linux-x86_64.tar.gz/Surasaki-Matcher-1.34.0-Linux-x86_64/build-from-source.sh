#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT/source"
if ! command -v cmake >/dev/null 2>&1 || ! command -v c++ >/dev/null 2>&1; then
  echo "CMake/C++ compiler is missing. Install build tools first." >&2
  exit 2
fi
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel
ctest --test-dir build --output-on-failure
cp build/surasaki-matcher "$ROOT/bin/surasaki-matcher"
chmod +x "$ROOT/bin/surasaki-matcher"
echo "Build complete: $ROOT/bin/surasaki-matcher"
