Surasaki Matcher 1.34.0 — Linux x86_64 package

FAST START (prebuilt executable)
1. Extract this archive.
2. If the system reports missing shared libraries, run:
   ./install-deps.sh
3. Run:
   ./run.sh --version
   ./run.sh self-test
   ./run.sh diagnostics
   ./run.sh

The included executable is built for Linux x86_64 and was verified with:
- CTest: 1/1 passed
- Crypto self-test: 8/8 passed

DEPENDENCIES
Runtime: OpenSSL 3, libstdc++, zlib, zstd, glibc.
Optional GPU/OpenCL functionality requires a working vendor OpenCL runtime/driver.

BUILD LOCALLY
If you want to compile on the target Linux machine:
- Debian/Ubuntu: sudo apt update && sudo apt install -y build-essential cmake libssl-dev
- then: ./build-from-source.sh

SOURCE
The complete original project source is under ./source.
No project source files were removed for packaging.
macOS __MACOSX metadata is intentionally not included in this Linux deployment archive.

EXAMPLES
./run.sh wallet inspect wallet.dat
./run.sh sldb inspect dictionary.sldb
./run.sh match exact --target 'example' dictionary.sldb
./run.sh match sha256 --target <64-hex> dictionary.sldb
./run.sh generate --alphabet 'abc123' --min 1 --max 6 --limit 100
./run.sh benchmark gpu --limit 8192

OFFLINE
The executable performs local/offline processing. It does not require a network service at runtime.
