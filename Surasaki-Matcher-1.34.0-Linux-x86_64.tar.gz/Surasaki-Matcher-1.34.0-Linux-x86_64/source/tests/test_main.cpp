#include "crypto_engine.hpp"
#include "sldb_reader.hpp"
#include "utils.hpp"
#include <iostream>
#include <cassert>

using namespace surasaki;
void run_extra_tests();

// Simple test runner
static int failures = 0;

#define CHECK(cond, msg) do { \
    if (!(cond)) { \
        std::cerr << "FAIL: " << msg << "\n"; \
        ++failures; \
    } else { \
        std::cerr << "PASS: " << msg << "\n"; \
    } \
} while(0)

int main() {
    std::cerr << "=== Unit tests ===\n";

    // Crypto self-test
    bool crypto_ok = run_crypto_self_test(false);
    CHECK(crypto_ok, "crypto self-test (all known-answer vectors)");

    // Hex round-trip
    {
        Bytes b = from_hex("deadbeef");
        CHECK(b.size() == 4 && b[0]==0xde && b[3]==0xef, "from_hex");
        CHECK(to_hex(b) == "deadbeef", "to_hex");
    }

    // SHA-256 empty
    {
        auto h = sha256(Bytes{});
        CHECK(to_hex(h) == "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
              "SHA-256 of empty");
    }

    run_extra_tests();
    std::cerr << "\n=== Results: " << (failures ? "FAILED" : "ALL PASSED") << " ===\n";
    return failures ? 1 : 0;
}
