#include "crypto_engine.hpp"
#include "gpu.hpp"
#include "gpu.hpp"
#include "sldb_reader.hpp"
#include "generator.hpp"
#include "matcher_targets.hpp"
#include "utf8.hpp"
#include "worker_pool.hpp"
#include "checkpoint.hpp"
#include "runtime.hpp"
#include "utils.hpp"
#include "session.hpp"
#include "dictionary_queue.hpp"
#include "performance.hpp"
#include "symbolic_runtime.hpp"
#include <cassert>
#include <atomic>
#include <filesystem>
#include <fstream>
#include <thread>
#include <vector>
using namespace surasaki;
static void u32(std::ofstream&f,uint32_t x){char b[4]={char(x),char(x>>8),char(x>>16),char(x>>24)};f.write(b,4);} static void u64(std::ofstream&f,uint64_t x){char b[8];for(int i=0;i<8;i++)b[i]=char(x>>(8*i));f.write(b,8);}
static std::filesystem::path make_sldb(){auto p=std::filesystem::temp_directory_path()/"surasaki_test.sldb";std::ofstream f(p,std::ios::binary|std::ios::trunc);f.write("SLDB",4);f.put(7);f.put(0);f.put(0);f.put(0);u64(f,5);for(int i=0;i<16;i++)f.put(0);for(const std::string&s:{"alpha","тест","","😀","hello"}){u32(f,(uint32_t)s.size());f.write(s.data(),(std::streamsize)s.size());}return p;}
void run_extra_tests(){assert(adaptive_worker_count(0, 3) >= 1 && adaptive_worker_count(2, 3) >= 1);auto p=make_sldb();SldbReader r(p.string());r.open();assert(r.header().version==7&&r.header().record_count==5);assert(*r.read_next()=="alpha");assert(*r.read_next()=="тест");assert(*r.read_next()=="");assert(*r.read_next()=="😀");assert(*r.read_next()=="hello");assert(!r.read_next());r.reset();assert(r.skip_records(2));assert(*r.read_next()=="");assert(valid_utf8("тест")&&valid_utf8("😀"));assert(!valid_utf8(std::string("\xC0\xAF",2)));
// Truncated record payload must be rejected rather than treated as EOF.
{
    auto badp=std::filesystem::temp_directory_path()/"surasaki_bad.sldb";
    std::ofstream f(badp,std::ios::binary|std::ios::trunc);
    f.write("SLDB",4); f.put(7); f.put(0); f.put(0); f.put(0); u64(f,1); for(int i=0;i<16;i++)f.put(0);
    u32(f,5); f.write("ab",2); f.close();
    bool threw=false; try { SldbReader br(badp.string()); br.open(); (void)br.read_next(); } catch(...) { threw=true; }
    assert(threw); std::filesystem::remove(badp);
}
// Declared record count must agree with physical EOF.
{
    auto badp=std::filesystem::temp_directory_path()/"surasaki_extra.sldb";
    std::ofstream f(badp,std::ios::binary|std::ios::trunc);
    f.write("SLDB",4); f.put(7); f.put(0); f.put(0); f.put(0); u64(f,0); for(int i=0;i<16;i++)f.put(0);
    u32(f,1); f.put('x'); f.close();
    bool threw=false; try { SldbReader br(badp.string()); br.open(); (void)br.read_next(); } catch(...) { threw=true; }
    assert(threw); std::filesystem::remove(badp);
}
SymbolicGenerator g({"ab",1,3});assert(g.total()==14);std::vector<std::string>v;while(auto x=g.next())v.push_back(*x);assert(v.front()=="a"&&v.back()=="bbb");assert(g.seek(BigInt("4"))&&*g.next()=="ba");
{ SymbolicGenerator ug({"😀а😀",1,2}); assert(ug.total()==6); assert(*ug.next()=="😀"); assert(*ug.next()=="а"); assert(*ug.next()=="😀😀"); }bool bad=false;try{(void)from_hex("zz");}catch(...){bad=true;}assert(bad);MatchTarget mt{MatchMode::Exact,"тест",{}};assert(mt.matches("тест")&&!mt.matches("test")); MatchTarget sh{MatchMode::Sha256,"",from_hex("2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824")}; assert(sh.matches("hello"));
std::atomic<int>n{0};WorkerPool wp(4,16);wp.start();for(int i=0;i<100;i++){while(!wp.submit([&]{n.fetch_add(1);}))std::this_thread::yield();}wp.wait_idle();wp.stop();assert(n==100);
auto d=std::filesystem::temp_directory_path()/"surasaki_ckpt";std::filesystem::remove_all(d);CheckpointStore cp(d.string());cp.set_session_prefix("abc");DictCheckpoint dc;dc.key="k";dc.name="x";dc.line=42;dc.total_lines=100;assert(cp.save_dict(dc));auto dl=cp.load_dict("k");assert(dl&&dl->line==42);
DictCheckpoint invalid_dc=dc; invalid_dc.progress=101.0; assert(cp.save_dict(invalid_dc)); assert(!cp.load_dict("k"));
assert(cp.clear_session());
DictionaryMatchJob job(p.string(),mt,RuntimeConfig{2,8,4});assert(job.start());job.wait();assert(job.state()==JobState::Found);auto rr=job.result();assert(rr&&rr->candidate=="тест"&&rr->record==1);
// Resume must keep absolute dictionary record numbering.
{ MatchTarget resume_target{MatchMode::Exact,"hello",{}}; DictionaryMatchJob resumed(p.string(),resume_target,RuntimeConfig{2,8,4,4}); assert(resumed.start()); resumed.wait(); assert(resumed.state()==JobState::Found); auto rres=resumed.result(); assert(rres && rres->record==4 && rres->candidate=="hello"); assert(resumed.position()>=5); } MatchTarget sh2{MatchMode::Sha256,"",from_hex("2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824")}; DictionaryMatchJob job2(p.string(),sh2,RuntimeConfig{2,8,4}); assert(job2.start()); job2.wait(); assert(job2.state()==JobState::Found); auto rr2=job2.result(); assert(rr2&&rr2->candidate=="hello");
// Session JSON round-trip and dictionary signature.
{
    auto sp=std::filesystem::temp_directory_path()/("surasaki_session_"+std::to_string(static_cast<unsigned long long>(std::hash<std::thread::id>{}(std::this_thread::get_id())))+".json");
    DictionarySession ss; ss.session_id="s1"; ss.wallet_hash="abc"; ss.target_mode="exact"; ss.target="hello"; ss.created_at=1; ss.updated_at=2; ss.processed=12; ss.skipped=2; ss.errors=1; ss.elapsed_seconds=3.5; ss.rate=4.25; ss.last_error="none"; ss.workers=4; ss.batch_size=32; ss.queue_capacity=64;
    DictionarySessionEntry de; de.key="k"; de.path=p.string(); de.name="surasaki_test.sldb"; de.signature=dictionary_signature(p.string()); de.line=2; de.total_lines=5; de.status="paused"; ss.dictionaries.push_back(de);
    if(!save_session_json(sp.string(),ss)) throw std::runtime_error("session save failed in test"); auto loaded=load_session_json(sp.string()); assert(loaded.session_id=="s1"&&loaded.dictionaries.size()==1&&loaded.dictionaries[0].line==2&&loaded.dictionaries[0].signature==de.signature); assert(loaded.processed==12&&loaded.skipped==2&&loaded.errors==1&&loaded.last_error=="none");
    std::filesystem::remove(sp);
}

// Multi-dictionary queue: automatic advance, signature binding, skip/retry/reset.
{
    auto p2=std::filesystem::temp_directory_path()/"surasaki_test2.sldb";
    std::ofstream f2(p2,std::ios::binary|std::ios::trunc); f2.write("SLDB",4); f2.put(7); f2.put(0); f2.put(0); f2.put(0); u64(f2,2); for(int i=0;i<16;i++)f2.put(0); u32(f2,3); f2.write("one",3); u32(f2,3); f2.write("two",3); f2.close();
    DictionarySession qs; qs.session_id="queue"; qs.target_mode="exact"; qs.target="two"; qs.workers=2; qs.batch_size=2; qs.queue_capacity=8; DictionarySessionEntry a; a.key="a"; a.path=p.string(); a.name="a"; a.signature=dictionary_signature(p.string()); a.status="new"; DictionarySessionEntry b; b.key="b"; b.path=p2.string(); b.name="b"; b.signature=dictionary_signature(p2.string()); b.status="new"; qs.dictionaries={a,b};
    DictionaryQueue dq(qs,QueueConfig{RuntimeConfig{2,8,2,0},true,{}}); auto qr=dq.run(MatchTarget{MatchMode::Exact,"two",{}}); assert(qr.state==QueueState::Found && qr.dictionary_index==1 && qr.match && qr.match->candidate=="two"); assert(dq.snapshot().dictionaries[0].status=="completed");
    auto snap=dq.snapshot(); DictionaryQueue dq2(snap); assert(dq2.skip_current()); assert(dq2.retry_current()); dq2.reset(); assert(dq2.snapshot().active_index==0 && dq2.snapshot().dictionaries[0].line==0); std::filesystem::remove(p2);
// Session paths in the current working directory must be valid.
{ auto cwd = std::filesystem::temp_directory_path()/"surasaki_cwd_session_test.json"; std::filesystem::remove(cwd); DictionarySession cs; cs.session_id="cwd"; assert(save_session_json(cwd.string(),cs)); assert(load_session_json(cwd.string()).session_id=="cwd"); std::filesystem::remove(cwd); }
}
// Symbolic runtime must drain pending work correctly when a match is found early.
{ SymbolicRunConfig sc; sc.workers=4; sc.batch_size=8; auto sr=run_symbolic_match({"ab",1,12},MatchTarget{MatchMode::Exact,"a",{}},sc); assert(sr.found && sr.candidate=="a" && sr.index==0); }
{ auto gi=detect_gpu(); assert(!gi.available || !gi.device.empty()); if(gi.available){ std::vector<std::string> gv={"abc"}; auto gh=sha256(reinterpret_cast<const uint8_t*>(gv[0].data()),gv[0].size()); auto gm=gpu_sha256_first_match(gv,gh,&gi); assert(gm==0); } }
// Wallet target abstraction: delegate to the existing single-candidate verifier.
{ WalletTargetContext ctx; ctx.config.mkey_cipher=from_hex("00112233445566778899aabbccddeeff"); ctx.config.salt=from_hex("0001020304050607"); ctx.config.iterations=1; ctx.config.ckey_cipher=from_hex("00112233445566778899aabbccddeeff"); ctx.config.pubkey=from_hex("0279be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798"); MatchTarget wt; wt.mode=MatchMode::Wallet; wt.wallet=std::make_shared<const WalletTargetContext>(ctx); bool threw=false; try{(void)wt.matches("test");}catch(...){threw=true;} assert(!threw); }
std::filesystem::remove(p);std::filesystem::remove_all(d);}
