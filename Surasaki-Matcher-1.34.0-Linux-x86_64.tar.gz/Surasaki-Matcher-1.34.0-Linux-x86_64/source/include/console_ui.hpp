#pragma once
#include <filesystem>
#include <string>
#include <vector>
namespace surasaki {
struct LocalFile { std::filesystem::path path; std::string kind; uint64_t size=0; };
std::vector<LocalFile> scan_local_files(const std::filesystem::path& dir);
int run_console_ui(const std::filesystem::path& program_dir);
}
