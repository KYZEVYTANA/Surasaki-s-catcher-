#pragma once
#include "utils.hpp"
#include "crypto_engine.hpp"
#include "matcher_targets.hpp"
#include <string>
#include <vector>
#include <optional>
#include <memory>

namespace surasaki {

struct MKey {
    uint32_t id = 0;
    Bytes    cipher;
    Bytes    salt;      // 8 bytes
    uint32_t method = 0;
    uint32_t iterations = 0;
};

struct CKey {
    Bytes pub;      // 33 or 65
    Bytes cipher;
    std::string type; // "ckey" or "ckeyA"
};

struct WalletAnalysis {
    std::string format;
    uint32_t    db_version = 0;
    uint32_t    page_size  = 0;
    size_t      page_count = 0;
    size_t      mkey_count = 0;
    size_t      ckey_count = 0;
    size_t      ckey_a_count = 0;
    size_t      hdchain_count = 0;
    size_t      key_count = 0;
    std::string encryption;
    std::string compatibility;
};

struct ParsedWallet {
    std::optional<MKey> mkey;
    std::vector<CKey>   ckeys;
    std::vector<CKey>   ckey_as;
    std::vector<MKey>   mkeys;
    WalletAnalysis      analysis;
};

ParsedWallet parse_bitcoin_wallet_dat(const Bytes& data);
std::string  render_wallet_analysis(const WalletAnalysis& a);

// Load file and return config ready for crypto if supported.
std::optional<WalletConfig> load_wallet_config(const std::string& path, std::string& status_msg);
std::shared_ptr<const WalletTargetContext> make_wallet_target_context(const std::string& path, std::string& status_msg);

} // namespace surasaki
