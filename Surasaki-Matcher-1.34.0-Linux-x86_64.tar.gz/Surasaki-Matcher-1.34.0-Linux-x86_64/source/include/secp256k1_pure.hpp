#pragma once
#include "utils.hpp"
#include "crypto_engine.hpp"
#include <string>

namespace surasaki {

// Derive compressed (33) or uncompressed (65) public key hex from 32-byte private key.
// Returns empty string on invalid private key.
std::string derive_pub_hex(const Bytes& priv32, bool compressed);

// Validate that decrypted 32-byte master key correctly decrypts the ckey and matches pubkey.
// IV for ckey = first 16 bytes of SHA256(SHA256(pubkey)).
CheckResult validate_ckey(const Bytes& master_key_32,
                          const Bytes& ckey_cipher,
                          const Bytes& pubkey);

} // namespace surasaki
