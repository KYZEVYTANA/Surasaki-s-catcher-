#pragma once
#include <functional>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <deque>
#include <atomic>
#include <vector>
namespace surasaki {
class WorkerPool { public: using Job=std::function<void()>; explicit WorkerPool(size_t workers=1,size_t capacity=128); ~WorkerPool(); void start(); bool submit(Job job); void pause(); void resume(); void stop(); void wait_idle(); size_t size()const{return workers_.size();} size_t queue_size()const; private: void loop(); size_t wanted_,capacity_; mutable std::mutex m_; std::condition_variable cv_,idle_; std::deque<Job> q_; std::vector<std::thread> workers_; bool stopping_=false,paused_=false; size_t active_=0; };
}
