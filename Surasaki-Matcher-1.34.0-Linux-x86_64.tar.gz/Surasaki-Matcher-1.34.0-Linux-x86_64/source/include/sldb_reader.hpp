#pragma once
#include "utils.hpp"
#include <fstream>
#include <memory>
#include <optional>
#include <string>

namespace surasaki {

struct SldbHeader {
    uint8_t  version = 0;
    uint8_t  flags   = 0;
    uint64_t record_count = 0;
};

class SldbReader {
public:
    explicit SldbReader(const std::string& path);
    ~SldbReader();

    void open();
    void close();
    void reset();

    // Skip to record index (0-based). Returns false if beyond end.
    bool skip_records(uint64_t count);

    // Read next record as UTF-8 string. Returns nullopt on EOF.
    std::optional<std::string> read_next();

    // Read next raw bytes.
    std::optional<Bytes> read_next_bytes();

    const SldbHeader& header() const { return header_; }
    uint64_t current_record() const { return record_no_; }
    bool is_open() const { return file_.is_open(); }

private:
    std::string path_;
    std::ifstream file_;
    SldbHeader header_;
    uint64_t record_no_ = 0;
    uint64_t file_size_ = 0;
    static constexpr size_t HEADER_SIZE = 32;
    static constexpr size_t MAX_RECORD = 64 * 1024 * 1024;

    void refill(size_t min_bytes);
    Bytes buffer_;
    size_t buf_pos_ = 0;
    size_t buf_end_ = 0;
    uint64_t file_offset_ = HEADER_SIZE;
};

} // namespace surasaki
