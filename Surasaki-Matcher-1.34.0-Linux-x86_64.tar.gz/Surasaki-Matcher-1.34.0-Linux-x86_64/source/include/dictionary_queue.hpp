#pragma once
#include "matcher_targets.hpp"
#include "session.hpp"
#include "runtime.hpp"
#include <cstddef>
#include <cstdint>
#include <functional>
#include <optional>
#include <string>
#include <vector>
#include <mutex>
#include <memory>

namespace surasaki {

enum class QueueState { Ready, Running, Paused, Stopped, Completed, Found, Failed };

struct QueueConfig {
    RuntimeConfig runtime{};
    bool verify_signatures = true;
    std::function<void(const DictionarySessionEntry&)> on_progress;
    std::string session_store_path;
    uint64_t autosave_interval_records = 1024;
};

struct QueueResult {
    QueueState state = QueueState::Ready;
    size_t dictionary_index = 0;
    std::optional<RuntimeResult> match;
    std::string error;
};

class DictionaryQueue {
public:
    explicit DictionaryQueue(DictionarySession session, QueueConfig config = {});
    QueueResult run(const MatchTarget& target);
    void request_pause();
    void request_resume();
    void request_stop();
    bool skip_current();
    bool retry_current();
    void reset();
    const DictionarySession& session() const noexcept { return session_; }
    DictionarySession snapshot() const { std::lock_guard<std::mutex> lock(state_mutex_); return session_; }
    bool running() const noexcept { std::lock_guard<std::mutex> lock(state_mutex_); return session_.running; }
private:
    bool find_next_selected(size_t from, size_t& index) const;
    void update_entry(size_t index, const std::string& status, uint64_t line, uint64_t total);
    DictionarySession session_;
    QueueConfig config_;
    std::shared_ptr<DictionaryMatchJob> active_job_;
    bool pause_requested_ = false;
    bool stop_requested_ = false;
    mutable std::mutex state_mutex_;
};

} // namespace surasaki
