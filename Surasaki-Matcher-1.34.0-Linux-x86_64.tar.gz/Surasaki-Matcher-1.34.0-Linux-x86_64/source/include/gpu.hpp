#pragma once
#include "utils.hpp"
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace surasaki {

struct GpuInfo {
    bool available = false;
    std::string platform;
    std::string device;
    std::string version;
    std::string reason;
};

GpuInfo detect_gpu();

struct GpuBenchmarkResult { bool available=false; double seconds=0.0; size_t candidates=0; double candidates_per_second=0.0; std::string device; std::string reason; };
GpuBenchmarkResult benchmark_gpu_sha256(size_t candidates = 8192);

// Generic SHA-256 batch matcher. Returns the first matching index within candidates,
// or SIZE_MAX when there is no match. The GPU path is optional and falls back cleanly.
size_t gpu_sha256_first_match(const std::vector<std::string>& candidates,
                              const Bytes& target,
                              GpuInfo* info = nullptr);

} // namespace surasaki
