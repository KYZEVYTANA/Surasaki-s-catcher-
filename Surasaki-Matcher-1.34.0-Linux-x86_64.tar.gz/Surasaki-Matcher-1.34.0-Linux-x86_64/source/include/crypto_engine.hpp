#pragma once
#include "utils.hpp"
#include <string>
#include <optional>

namespace surasaki {

struct EvpKeyIv {
    Bytes key; // 32 bytes
    Bytes iv;  // 16 bytes
};

// Exact Bitcoin Core legacy: EVP_BytesToKey(AES-256-CBC, SHA-512, password, salt, count)
// Uses OpenSSL EVP_BytesToKey under the hood for bit-exact match with Bitcoin Core.
EvpKeyIv evp_bytes_to_key_sha512(const Bytes& password, const Bytes& salt, int count);

// AES-256-CBC decrypt with PKCS#7 padding (OpenSSL).
// Returns plaintext or throws on failure (bad padding etc.).
Bytes aes256_cbc_decrypt(const Bytes& key, const Bytes& iv, const Bytes& ciphertext);

// SHA-256
Bytes sha256(const Bytes& data);
Bytes sha256(const uint8_t* data, size_t len);

// Full wallet candidate check (mkey decrypt + ckey validation).
struct WalletConfig {
    Bytes mkey_cipher;
    Bytes salt;          // 8 bytes
    int   iterations = 0;
    Bytes ckey_cipher;
    Bytes pubkey;        // 33 or 65 bytes
};

enum class CheckStatus { Valid, Invalid, Unknown };

struct CheckResult {
    CheckStatus status = CheckStatus::Invalid;
    std::string reason;
};

CheckResult check_wallet_candidate(const std::string& candidate, const WalletConfig& cfg);

// Self-test with known-answer vectors from the original JS.
bool run_crypto_self_test(bool verbose = true);

} // namespace surasaki
