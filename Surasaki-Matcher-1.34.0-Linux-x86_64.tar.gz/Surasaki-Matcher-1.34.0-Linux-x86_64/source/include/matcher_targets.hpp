#pragma once
#include "utils.hpp"
#include "crypto_engine.hpp"
#include <memory>
#include <string>

namespace surasaki {

enum class MatchMode { Exact, Sha256, Wallet };

// Immutable verification context prepared once from a legacy wallet.dat.
// It contains only the data required by the existing single-candidate wallet
// verifier; the wallet file itself is never reparsed during matching.
struct WalletTargetContext {
    WalletConfig config;
    std::string wallet_identity;
};

struct MatchTarget {
    MatchMode mode = MatchMode::Exact;
    std::string exact;
    Bytes sha256_target;
    bool normalize_trim = true;
    std::shared_ptr<const WalletTargetContext> wallet;

    MatchTarget() = default;
    MatchTarget(MatchMode m, std::string e, Bytes h, bool trim = true,
                std::shared_ptr<const WalletTargetContext> w = {})
        : mode(m), exact(std::move(e)), sha256_target(std::move(h)),
          normalize_trim(trim), wallet(std::move(w)) {}

    bool matches(const std::string& candidate) const;
};

} // namespace surasaki
