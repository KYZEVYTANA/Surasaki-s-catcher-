#pragma once
#include <cstddef>
#include <string_view>
namespace surasaki { bool valid_utf8(std::string_view s); size_t utf8_codepoints(std::string_view s); }
