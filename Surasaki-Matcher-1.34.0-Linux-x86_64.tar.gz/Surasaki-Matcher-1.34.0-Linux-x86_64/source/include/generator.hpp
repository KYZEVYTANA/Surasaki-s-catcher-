#pragma once
#include <boost/multiprecision/cpp_int.hpp>
#include <string>
#include <optional>
#include <vector>
namespace surasaki {
using BigInt=boost::multiprecision::cpp_int;
struct GeneratorConfig { std::string alphabet; unsigned min_length=1,max_length=1; };
class SymbolicGenerator { public: explicit SymbolicGenerator(GeneratorConfig c); const GeneratorConfig& config() const{return cfg_;} const BigInt& index() const{return index_;} BigInt total() const; bool seek(const BigInt& i); std::optional<std::string> next(); void reset(); private: GeneratorConfig cfg_; std::vector<std::string> symbols_; BigInt index_=0; BigInt total_=0; void recompute(); void build_symbols(); std::optional<std::string> at(const BigInt&) const; };
}
