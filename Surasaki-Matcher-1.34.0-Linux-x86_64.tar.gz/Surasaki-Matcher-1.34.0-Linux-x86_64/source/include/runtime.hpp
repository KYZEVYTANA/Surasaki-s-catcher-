#pragma once
#include "dictionary_engine.hpp"
#include "matcher_targets.hpp"
#include "worker_pool.hpp"
#include "stats.hpp"
#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <thread>
#include <functional>

namespace surasaki {
enum class JobState { Created, Ready, Running, Paused, Stopped, Completed, Found, Failed };
struct RuntimeConfig { size_t workers=1, queue_capacity=256, batch_size=32; uint64_t start_record=0; uint64_t progress_interval=1024; std::function<void(uint64_t,uint64_t,const Statistics&)> on_progress; };
struct RuntimeResult { bool matched=false; uint64_t record=0; std::string candidate; std::string error; };
class DictionaryMatchJob {
public:
    DictionaryMatchJob(std::string path, MatchTarget target, RuntimeConfig cfg={});
    ~DictionaryMatchJob();
    bool start(); void pause(); void resume(); void stop(); void wait();
    JobState state() const { return state_.load(); }
    const Statistics& stats() const { return stats_; }
    uint64_t position() const { return committed_.load(); }
    uint64_t total() const { return total_; }
    std::optional<RuntimeResult> result() const; std::string error() const;
private:
    void run();
    std::string path_; MatchTarget target_; RuntimeConfig cfg_;
    std::unique_ptr<DictionaryEngine> source_; WorkerPool pool_; Statistics stats_;
    std::atomic<JobState> state_{JobState::Created}; std::atomic<uint64_t> committed_{0}; uint64_t total_=0;
    mutable std::mutex result_mutex_; std::optional<RuntimeResult> result_; std::string error_;
    std::mutex control_mutex_, submit_mutex_; std::condition_variable control_cv_, submit_cv_;
    bool paused_=false; std::atomic<bool> stopped_{false}; std::thread coordinator_;
};
}
