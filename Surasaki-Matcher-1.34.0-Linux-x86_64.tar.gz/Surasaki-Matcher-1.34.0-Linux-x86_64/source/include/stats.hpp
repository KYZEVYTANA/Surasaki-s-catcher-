#pragma once
#include <atomic>
#include <cstdint>
#include <chrono>
namespace surasaki {
class Statistics { public: void reset(); void processed(uint64_t n=1); void skipped(uint64_t n=1); void error(uint64_t n=1); uint64_t processed_count()const{return processed_.load();} uint64_t skipped_count()const{return skipped_.load();} uint64_t error_count()const{return errors_.load();} double elapsed()const; double rate()const; private: std::atomic<uint64_t> processed_{0},skipped_{0},errors_{0}; std::chrono::steady_clock::time_point started_=std::chrono::steady_clock::now(); };
}
