#pragma once
#include "sldb_reader.hpp"
#include "stats.hpp"
#include <memory>
#include <functional>
namespace surasaki {
struct DictionaryInfo { std::string path; uint64_t records=0; uint64_t current=0; std::string status="new"; };
class DictionaryEngine { public: explicit DictionaryEngine(std::string path); void open(); void reset(); bool next(std::string& out); bool seek(uint64_t record); const DictionaryInfo& info()const{return info_;} const Statistics& stats()const{return stats_;} void pause(){paused_=true;} void resume(){paused_=false;} private: SldbReader reader_; DictionaryInfo info_; Statistics stats_; bool paused_=false; };
}
