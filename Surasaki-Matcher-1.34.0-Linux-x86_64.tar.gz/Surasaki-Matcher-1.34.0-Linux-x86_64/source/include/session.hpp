#pragma once
#include "checkpoint.hpp"
#include <cstdint>
#include <string>
#include <vector>

namespace surasaki {

struct DictionarySessionEntry {
    std::string key;
    std::string path;
    std::string name;
    std::string signature;
    bool selected = true;
    std::string status = "new";
    uint64_t line = 0;
    uint64_t total_lines = 0;
};

struct DictionarySession {
    uint32_t schema = 1;
    std::string session_id;
    std::string wallet_hash;
    std::string target_mode;
    std::string target;
    uint64_t created_at = 0;
    uint64_t updated_at = 0;
    size_t workers = 1;
    size_t batch_size = 32;
    size_t queue_capacity = 256;
    size_t active_index = 0;
    bool running = false;
    uint64_t processed = 0;
    uint64_t skipped = 0;
    uint64_t errors = 0;
    double elapsed_seconds = 0.0;
    double rate = 0.0;
    std::string last_error;
    std::vector<DictionarySessionEntry> dictionaries;
};

std::string dictionary_signature(const std::string& path);
std::string session_to_json(const DictionarySession& session);
DictionarySession session_from_json(const std::string& json);
bool save_session_json(const std::string& path, const DictionarySession& session);
DictionarySession load_session_json(const std::string& path);

class DictionarySessionStore {
public:
    explicit DictionarySessionStore(std::string path);
    void save(const DictionarySession& session) const;
    DictionarySession load() const;
    bool exists() const;
    void remove() const;
private:
    std::string path_;
};

} // namespace surasaki
