#pragma once
#include "utils.hpp"
#include <string>
#include <optional>
#include <cstdint>

namespace surasaki {

struct DictCheckpoint {
    std::string key;
    std::string name;
    bool        selected = true;
    std::string status = "new"; // new, running, paused, done, error
    double      progress = 0.0;
    uint64_t    line = 0;
    uint64_t    total_lines = 0;
    int64_t     last_checkpoint = 0;
};

struct BruteCheckpoint {
    uint64_t idx = 0;
    int      len = 1;
    double   progress = 0.0;
    int64_t  timestamp = 0;
};

struct FoundState {
    bool        found = false;
    std::string candidate;
    std::string source;
    int64_t     timestamp = 0;
};

class CheckpointStore {
public:
    explicit CheckpointStore(const std::string& dir = ".surasaki_state");

    void set_session_prefix(const std::string& wallet_hash);

    bool save_dict(const DictCheckpoint& e);
    std::optional<DictCheckpoint> load_dict(const std::string& key);

    bool save_brute(const BruteCheckpoint& b);
    std::optional<BruteCheckpoint> load_brute();

    bool save_found(const FoundState& f);
    std::optional<FoundState> load_found();

    bool clear_session();

private:
    std::string dir_;
    std::string prefix_;
    std::string path_for(const std::string& name) const;
};

} // namespace surasaki
