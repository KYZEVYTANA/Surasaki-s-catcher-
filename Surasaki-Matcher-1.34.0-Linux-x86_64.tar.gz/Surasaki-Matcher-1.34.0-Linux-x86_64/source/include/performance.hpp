#pragma once
#include "runtime.hpp"
#include <cstddef>
#include <string>
namespace surasaki {
enum class PerformanceProfile { Eco, Balanced, Maximum };
struct PerformanceSettings { PerformanceProfile profile=PerformanceProfile::Balanced; size_t workers=1; size_t batch_size=32; size_t queue_capacity=256; uint64_t progress_interval=1024; };
PerformanceSettings performance_settings(PerformanceProfile p, size_t hardware_threads);
size_t adaptive_worker_count(size_t requested, size_t hardware_threads = 0);
PerformanceProfile parse_profile(const std::string& name);
const char* profile_name(PerformanceProfile p);
}
