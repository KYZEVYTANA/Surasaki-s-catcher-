#pragma once
#include "generator.hpp"
#include "matcher_targets.hpp"
#include "stats.hpp"
#include <cstddef>
#include <cstdint>
#include <functional>
#include <optional>
namespace surasaki {
struct SymbolicRunConfig { size_t workers=1; size_t batch_size=32; uint64_t start=0; uint64_t limit=0; std::function<void(const BigInt&,const BigInt&,const Statistics&)> on_progress; };
struct SymbolicRunResult { bool found=false; BigInt index=0; std::string candidate; BigInt processed=0; };
SymbolicRunResult run_symbolic_match(const GeneratorConfig&, const MatchTarget&, const SymbolicRunConfig& cfg=SymbolicRunConfig{});
}
