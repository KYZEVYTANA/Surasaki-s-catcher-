#pragma once
#include "generator.hpp"
#include <cstdint>
namespace surasaki { double percent(uint64_t current,uint64_t total); double percent(const BigInt& current,const BigInt& total); }
