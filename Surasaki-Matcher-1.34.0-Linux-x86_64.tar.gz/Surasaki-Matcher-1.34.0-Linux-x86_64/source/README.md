# Surasaki Matcher 1.34.0 — native Linux C++ runtime

Native C++20 Linux implementation of the reusable Surasaki Matcher runtime. It is fully offline at runtime and works with local SLDB v7 dictionaries and local Bitcoin Core legacy wallet files.

## Build

```bash
sudo apt update
sudo apt install -y build-essential cmake libssl-dev
make
make test
make selftest
```

Optional sanitizer build:

```bash
cmake -S . -B build-asan -DCMAKE_BUILD_TYPE=Debug -DSURASAKI_SANITIZERS=ON
cmake --build build-asan --parallel
ctest --test-dir build-asan --output-on-failure
```

## CLI

```bash
./build/surasaki-matcher --version
./build/surasaki-matcher self-test
./build/surasaki-matcher wallet inspect wallet.dat
./build/surasaki-matcher sldb inspect dictionary.sldb
./build/surasaki-matcher sldb scan dictionary.sldb --start 0 --limit 100
./build/surasaki-matcher generate --alphabet 'abc123' --min 1 --max 6 --limit 100
./build/surasaki-matcher match exact --target 'example' dictionary.sldb
./build/surasaki-matcher match exact --target 'example' --no-trim dictionary.sldb
./build/surasaki-matcher wallet verify wallet.dat --candidate 'one-candidate'
./build/surasaki-matcher match sha256 --target <64-hex> dictionary.sldb
./build/surasaki-matcher benchmark sldb dictionary.sldb --limit 100000
./build/surasaki-matcher benchmark gpu --limit 8192
./build/surasaki-matcher benchmark generator --alphabet 'abc123' --min 1 --max 6 --limit 100000
./build/surasaki-matcher diagnostics
```

## Implemented components

- OpenSSL EVP crypto engine: Bitcoin legacy `EVP_BytesToKey` / SHA-512 and AES-256-CBC primitives, plus SHA-256.
- Legacy Bitcoin wallet analyzer with BDB page scanning and mkey/ckey extraction.
- secp256k1 public-key derivation and ckey validation.
- SLDB v7 streaming reader with bounded buffering, record-size checks, EOF/count consistency checks and UTF-8 validation.
- DictionaryEngine with open/reset/seek/next/pause/resume and streaming statistics.
- SymbolicGenerator with UTF-8 code-point alphabet semantics matching the browser generator (duplicate symbols removed) and `boost::multiprecision::cpp_int` indexing.
- Bounded WorkerPool with start/submit/pause/resume/stop/idle semantics.
- Ordered dictionary runtime: worker completions are committed in source-record order, so progress never moves backwards.
- Exact and SHA-256 matching for generic SLDB records; exact mode trims Unicode whitespace by default like the HTML checkbox default, with `--no-trim` for byte-exact string comparison.
- 64-bit/BigInt-safe progress calculations and throughput statistics.
- Atomic session checkpoint persistence with validation.
- CMake, Makefile and CTest integration.

## Offline operation

After installation, the executable does not contact a network service. Input files, checkpoints and all processing remain local. Internet access is only needed if the operator separately chooses to obtain the executable, dictionaries, dependencies or other input files.

## Wallet boundary

The native runtime does not expose an automated batch password-guessing command against encrypted wallets. The wallet cryptographic routines are retained as low-level primitives and for controlled validation/self-tests; generic dictionary/symbolic generation and non-wallet matching are available as independent components.

## Correctness and testing

The test suite covers SLDB v7 parsing, malformed/truncated records, UTF-8 validation, generator ordering and arbitrary-precision seeking, exact/SHA-256 matching, worker-pool execution, atomic checkpoints and the dictionary runtime. The project can also be built with AddressSanitizer and UndefinedBehaviorSanitizer.

The 1.95 GB / 114,068,041-record production SecLists dictionary is not bundled with the source archive, so the project does not claim a complete scan of that particular file here.


## Dictionary sessions

Version 1.19 adds a local JSON session format for dictionary queues and checkpoints.
The session stores dictionary paths, signatures, selection/status, committed record position, target metadata, and worker settings. Dictionary signatures are derived from the file name, size, filesystem modification timestamp, and are checked by the session layer before reuse.

The `session signature` command prints the signature of one SLDB file; `session export` creates an empty session document and `session import` validates and reads a session document. All session files are local and require no network service.

## ASCII console and local file discovery

Running `./build/surasaki-matcher` with no command opens the ASCII console. It scans the executable directory, the current directory, and the executable parent directory for `.sldb`, `.dat`, and `.json` files, then presents them for selection. A rescan is available without restarting the program.

The console never requires a network service. Dictionary and wallet/data files are read locally. The console is intentionally smaller than the browser UI; browser-only theme/IndexedDB presentation is replaced by the native ASCII console and JSON sessions.

## Compute backends

Worker count is not capped at 10. `--workers N` accepts any positive `size_t` value; `--workers 0` selects an adaptive value from the available CPU threads and the host/cgroup process limits. If the OS refuses additional worker threads, the pool keeps the workers it successfully created rather than failing the whole run.

The console's SHA-256 matcher supports `auto`, `cpu`, and `gpu`. `auto` uses an OpenCL GPU when an OpenCL GPU device is actually available and otherwise falls back to CPU. The GPU path is a native optional OpenCL backend loaded at runtime, so OpenCL headers are not required to build the application. Exact string matching remains CPU-side because it is dominated by sequential dictionary I/O and comparison rather than cryptographic arithmetic. Candidates longer than the single-block GPU SHA-256 fast path are checked by CPU, so they are not silently skipped.

GPU support therefore depends on a working vendor OpenCL runtime/driver. Use `surasaki-matcher diagnostics`, `benchmark gpu`, or menu item `[6]`/`[8]` to inspect and benchmark the detected device.

## Console startup

```bash
./build/surasaki-matcher
# or
./build/surasaki-matcher console
```

The console is intentionally ASCII-only and does not depend on ncurses or a graphical desktop.

## Crash/resume recovery

Session runs persist progress atomically. The next `session run` resumes from the last committed record. If a crash left `running=true`, `session recover <file.json>` explicitly marks in-flight entries as paused and clears the stale running flag before resuming. Because checkpoints are written periodically, a crash may replay a bounded tail of records; it does not intentionally skip ahead. Dictionary signatures are revalidated before reuse, so a changed dictionary is rejected rather than silently resumed. A session with `running=true` is therefore treated as recoverable state, not as proof that another process is still alive.

## 1.32 finalization

The release adds adaptive worker budgeting, GPU SHA-256 benchmarking, explicit recovery semantics, and the portable adjacent-file discovery already used by the ASCII console. The real 1.95 GB SecLists production file is still not bundled and has not been claimed as scanned unless supplied locally.
