#include "generator.hpp"
#include "utf8.hpp"
#include <stdexcept>
#include <unordered_set>

namespace surasaki {

SymbolicGenerator::SymbolicGenerator(GeneratorConfig c):cfg_(std::move(c)){
    if(cfg_.alphabet.empty()) throw std::invalid_argument("alphabet is empty");
    if(cfg_.min_length>cfg_.max_length) throw std::invalid_argument("min_length > max_length");
    build_symbols();
    recompute();
}

void SymbolicGenerator::build_symbols(){
    if(!valid_utf8(cfg_.alphabet)) throw std::invalid_argument("alphabet must be valid UTF-8");
    std::unordered_set<std::string> seen;
    for(size_t i=0;i<cfg_.alphabet.size();){
        const unsigned char c=static_cast<unsigned char>(cfg_.alphabet[i]);
        size_t n=1;
        if(c<0x80) n=1;
        else if((c&0xE0)==0xC0) n=2;
        else if((c&0xF0)==0xE0) n=3;
        else if((c&0xF8)==0xF0) n=4;
        else throw std::invalid_argument("alphabet contains invalid UTF-8");
        if(i+n>cfg_.alphabet.size()) throw std::invalid_argument("alphabet contains truncated UTF-8");
        std::string cp=cfg_.alphabet.substr(i,n);
        if(seen.insert(cp).second) symbols_.push_back(std::move(cp));
        i+=n;
    }
    if(symbols_.empty()) throw std::invalid_argument("alphabet is empty");
}

void SymbolicGenerator::recompute(){
    total_=0; BigInt p=1; const BigInt radix=symbols_.size();
    for(unsigned l=1;l<=cfg_.max_length;++l){ p*=radix; if(l>=cfg_.min_length) total_+=p; }
}

BigInt SymbolicGenerator::total() const{return total_;}

std::optional<std::string> SymbolicGenerator::at(const BigInt& x) const {
    BigInt q=x; BigInt p=1; const BigInt radix=symbols_.size();
    for(unsigned l=1;l<=cfg_.max_length;++l){
        p*=radix;
        if(l<cfg_.min_length) continue;
        if(q<p){
            std::vector<size_t> idx(l);
            for(int i=(int)l-1;i>=0;--i){ idx[i]=(q%radix).convert_to<size_t>(); q/=radix; }
            std::string out;
            size_t bytes=0; for(size_t j:idx) bytes+=symbols_[j].size(); out.reserve(bytes);
            for(size_t j:idx) out+=symbols_[j];
            return out;
        }
        q-=p;
    }
    return std::nullopt;
}

bool SymbolicGenerator::seek(const BigInt&i){if(i<0||i>total_)return false;index_=i;return true;}
std::optional<std::string> SymbolicGenerator::next(){auto r=at(index_);if(r)++index_;return r;}
void SymbolicGenerator::reset(){index_=0;}

} // namespace surasaki
