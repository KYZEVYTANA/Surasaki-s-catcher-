#include "console_ui.hpp"
#include "gpu.hpp"
#include "sldb_reader.hpp"
#include "wallet_parser.hpp"
#include "dictionary_engine.hpp"
#include "matcher_targets.hpp"
#include "runtime.hpp"
#include "performance.hpp"
#include <algorithm>
#include <chrono>
#include <iostream>
#include <limits>
#include <thread>

namespace surasaki {
namespace fs=std::filesystem;

std::vector<LocalFile> scan_local_files(const fs::path& dir){
 std::vector<LocalFile> out; std::error_code ec;
 if(!fs::exists(dir,ec)) return out;
 for(auto const& e:fs::directory_iterator(dir,ec)){if(ec)break;if(!e.is_regular_file(ec))continue;auto ext=e.path().extension().string();std::string k;if(ext==".sldb")k="SLDB dictionary";else if(ext==".dat")k="wallet/data";else if(ext==".json")k="session";else continue;uint64_t z=0;z=fs::file_size(e.path(),ec);out.push_back({e.path(),k,z});}
 std::sort(out.begin(),out.end(),[](auto&a,auto&b){return a.path.filename().string()<b.path.filename().string();});return out;
}
static void clear_input(){std::cin.clear();std::string x;std::getline(std::cin,x);}
static size_t ask_index(size_t n){if(!n)return std::numeric_limits<size_t>::max();std::cout<<"Select number: ";size_t i;if(!(std::cin>>i)){clear_input();return std::numeric_limits<size_t>::max();}clear_input();return i<n?i:std::numeric_limits<size_t>::max();}
static MatchTarget make_target(const std::string& mode,const std::string& t){if(mode=="exact")return MatchTarget{MatchMode::Exact,t,{}};auto b=from_hex(t);if(b.size()!=32)throw std::runtime_error("SHA-256 target must be exactly 64 hex characters");return MatchTarget{MatchMode::Sha256,"",b};}
static void header(){std::cout<<"\n============================================================\n  SURASAKI MATCHER 1.34.0 — ASCII CONSOLE\n============================================================\n";}
int run_console_ui(const fs::path& program_dir){
 auto dir=program_dir; if(dir.empty())dir=fs::current_path();
 for(;;){header();std::vector<LocalFile> files; std::vector<fs::path> roots={dir,fs::current_path(),dir.parent_path()}; for(const auto& root:roots){for(auto f:scan_local_files(root)){if(std::none_of(files.begin(),files.end(),[&](const LocalFile& x){return fs::equivalent(x.path,f.path);})) files.push_back(std::move(f));}} std::sort(files.begin(),files.end(),[](const LocalFile&a,const LocalFile&b){return a.path.filename().string()<b.path.filename().string();});std::cout<<"Working directory: "<<dir<<"\nFiles beside executable: "<<files.size()<<"\n\n";for(size_t i=0;i<files.size();++i)std::cout<<" ["<<i<<"] "<<files[i].kind<<"  "<<files[i].path.filename().string()<<"  "<<files[i].size<<" bytes\n";std::cout<<"\n [R] Rescan   [1] Inspect SLDB   [2] Inspect wallet/data\n [3] Match exact   [4] Match SHA-256   [5] Benchmark SLDB\n [6] System/GPU diagnostics   [8] GPU benchmark   [7] Change directory   [0] Exit\n > ";std::string cmd;std::getline(std::cin,cmd);if(cmd=="0"||cmd=="q"||cmd=="Q")return 0;
 if(cmd=="r"||cmd=="R")continue;
 if(cmd=="8"){auto r=benchmark_gpu_sha256(8192);if(r.available)std::cout<<"GPU: "<<r.device<<"  "<<r.candidates_per_second<<" candidates/sec\n";else std::cout<<"GPU unavailable: "<<r.reason<<"\n";std::cout<<"Press Enter...";std::getline(std::cin,cmd);continue;}
 if(cmd=="7"){std::cout<<"Directory: ";std::string p;std::getline(std::cin,p);if(!p.empty()&&fs::is_directory(p))dir=fs::absolute(p);else std::cout<<"Invalid directory\n";continue;}
 if(cmd=="6"){auto g=detect_gpu();std::cout<<"CPU hardware threads: "<<std::thread::hardware_concurrency()<<"\nGPU backend: "<<(g.available?"AVAILABLE":"not available")<<"\n";if(g.available)std::cout<<"Platform: "<<g.platform<<"\nDevice:   "<<g.device<<"\nOpenCL:   "<<g.version<<"\n";else std::cout<<"Reason:   "<<g.reason<<"\n";std::cout<<"Press Enter...";std::getline(std::cin,cmd);continue;}
 if(cmd=="1"){std::vector<size_t> ix;for(size_t i=0;i<files.size();++i)if(files[i].kind=="SLDB dictionary")ix.push_back(i);if(ix.empty()){std::cout<<"No .sldb files found.\n";continue;}std::cout<<"SLDB files:\n";for(size_t j=0;j<ix.size();++j)std::cout<<" ["<<j<<"] "<<files[ix[j]].path.filename().string()<<"\n";size_t j=ask_index(ix.size());if(j==std::numeric_limits<size_t>::max())continue;try{SldbReader r(files[ix[j]].path.string());r.open();std::cout<<"Version: "<<(int)r.header().version<<"\nRecords: "<<r.header().record_count<<"\nFirst records:\n";for(int n=0;n<5;n++){auto s=r.read_next();if(!s)break;std::cout<<"  "<<*s<<"\n";}}catch(std::exception&e){std::cout<<"ERROR: "<<e.what()<<"\n";}std::cout<<"Press Enter...";std::getline(std::cin,cmd);continue;}
 if(cmd=="2"){std::vector<size_t> ix;for(size_t i=0;i<files.size();++i)if(files[i].kind=="wallet/data")ix.push_back(i);if(ix.empty()){std::cout<<"No .dat files found.\n";continue;}std::cout<<"Data files:\n";for(size_t j=0;j<ix.size();++j)std::cout<<" ["<<j<<"] "<<files[ix[j]].path.filename().string()<<"\n";size_t j=ask_index(ix.size());if(j==std::numeric_limits<size_t>::max())continue;std::string st;auto c=load_wallet_config(files[ix[j]].path.string(),st);std::cout<<st<<"\n";if(c)std::cout<<"Legacy wallet structure recognized.\n";std::cout<<"Press Enter...";std::getline(std::cin,cmd);continue;}
 if(cmd=="3"||cmd=="4"){std::vector<size_t> ix;for(size_t i=0;i<files.size();++i)if(files[i].kind=="SLDB dictionary")ix.push_back(i);if(ix.empty()){std::cout<<"No .sldb files found.\n";continue;}std::cout<<"Dictionary:\n";for(size_t j=0;j<ix.size();++j)std::cout<<" ["<<j<<"] "<<files[ix[j]].path.filename().string()<<"\n";size_t j=ask_index(ix.size());if(j==std::numeric_limits<size_t>::max())continue;std::string target;std::cout<<(cmd=="3"?"Exact target: ":"SHA-256 target (64 hex): ");std::getline(std::cin,target);try{auto t=make_target(cmd=="3"?"exact":"sha256",target);size_t hw=std::max(1u,std::thread::hardware_concurrency());std::cout<<"Workers (0=auto, any positive value allowed): ";std::string ws;std::getline(std::cin,ws);size_t requested=ws.empty()?0:std::stoull(ws);size_t workers=adaptive_worker_count(requested,hw);std::cout<<"Effective workers: "<<workers<<"\n";std::cout<<"Backend [auto/cpu/gpu]: ";std::string be;std::getline(std::cin,be);if(be.empty())be="auto";
 if(cmd=="4"&&be!="cpu"){std::cout<<"Reading batches and using OpenCL GPU when available...\n";SldbReader r(files[ix[j]].path.string());r.open();std::vector<std::string> batch;batch.reserve(8192);uint64_t base=0;for(;;){batch.clear();for(size_t k=0;k<8192;k++){auto s=r.read_next();if(!s)break;batch.push_back(std::move(*s));}if(batch.empty())break;GpuInfo gi;size_t m=gpu_sha256_first_match(batch,t.sha256_target,&gi);if(gi.available){if(m!=SIZE_MAX){std::cout<<"MATCH record="<<base+m<<" value="<<batch[m]<<" [GPU "<<gi.device<<"]\n";break;}}else if(be=="gpu"){throw std::runtime_error("GPU requested but unavailable: "+gi.reason);}else{std::cout<<"GPU unavailable; falling back to CPU.\n";RuntimeConfig rc;rc.workers=workers;rc.batch_size=128;rc.queue_capacity=workers*8;DictionaryMatchJob job(files[ix[j]].path.string(),t,rc);if(!job.start())throw std::runtime_error(job.error());job.wait();if(auto rr=job.result())std::cout<<"MATCH record="<<rr->record<<" value="<<rr->candidate<<"\n";else std::cout<<"No match\n";break;}base+=batch.size();}}
 else {RuntimeConfig rc;rc.workers=workers;rc.batch_size=128;rc.queue_capacity=workers*8;DictionaryMatchJob job(files[ix[j]].path.string(),t,rc);if(!job.start())throw std::runtime_error(job.error());job.wait();if(auto rr=job.result())std::cout<<"MATCH record="<<rr->record<<" value="<<rr->candidate<<"\n";else std::cout<<"No match\n";}
 }catch(std::exception&e){std::cout<<"ERROR: "<<e.what()<<"\n";}std::cout<<"Press Enter...";std::getline(std::cin,cmd);continue;}
 if(cmd=="5"){std::vector<size_t> ix;for(size_t i=0;i<files.size();++i)if(files[i].kind=="SLDB dictionary")ix.push_back(i);if(ix.empty()){std::cout<<"No .sldb files found.\n";continue;}for(size_t j=0;j<ix.size();++j)std::cout<<" ["<<j<<"] "<<files[ix[j]].path.filename().string()<<"\n";size_t j=ask_index(ix.size());if(j==std::numeric_limits<size_t>::max())continue;try{SldbReader r(files[ix[j]].path.string());r.open();auto lim=std::min<uint64_t>(r.header().record_count,1000000);auto t0=std::chrono::steady_clock::now();uint64_t n=0;while(n<lim&&r.read_next())++n;double sec=std::chrono::duration<double>(std::chrono::steady_clock::now()-t0).count();std::cout<<"Records: "<<n<<"  seconds: "<<sec<<"  records/sec: "<<(sec?n/sec:0)<<"\n";}catch(std::exception&e){std::cout<<"ERROR: "<<e.what()<<"\n";}std::cout<<"Press Enter...";std::getline(std::cin,cmd);continue;}
 }
}
} // namespace surasaki
