#include "sldb_reader.hpp"
#include <cstring>
#include <stdexcept>
#include "utf8.hpp"

namespace surasaki {

SldbReader::SldbReader(const std::string& path) : path_(path) {
    buffer_.resize(512 * 1024);
}

SldbReader::~SldbReader() {
    close();
}

void SldbReader::open() {
    file_.open(path_, std::ios::binary);
    if (!file_)
        throw std::runtime_error("Cannot open SLDB file: " + path_);

    file_.seekg(0, std::ios::end);
    file_size_ = static_cast<uint64_t>(file_.tellg());
    file_.seekg(0, std::ios::beg);

    if (file_size_ < HEADER_SIZE)
        throw std::runtime_error("Corrupted SLDB — file shorter than 32-byte header");

    uint8_t h[HEADER_SIZE];
    file_.read(reinterpret_cast<char*>(h), HEADER_SIZE);
    if (file_.gcount() != static_cast<std::streamsize>(HEADER_SIZE))
        throw std::runtime_error("Failed to read SLDB header");

    if (h[0] != 0x53 || h[1] != 0x4c || h[2] != 0x44 || h[3] != 0x42)
        throw std::runtime_error("Invalid SLDB magic (expected SLDB)");

    header_.version = h[4];
    if (header_.version != 7)
        throw std::runtime_error("Unsupported SLDB version: " + std::to_string(header_.version));

    header_.flags = h[5];
    header_.record_count = read_u64_le(h + 8);

    record_no_ = 0;
    file_offset_ = HEADER_SIZE;
    buf_pos_ = buf_end_ = 0;
    file_.seekg(HEADER_SIZE, std::ios::beg);
}

void SldbReader::close() {
    if (file_.is_open()) file_.close();
    buffer_.clear();
    buf_pos_ = buf_end_ = 0;
}

void SldbReader::reset() {
    if (!file_.is_open()) open();
    record_no_ = 0;
    file_offset_ = HEADER_SIZE;
    buf_pos_ = buf_end_ = 0;
    file_.clear();
    file_.seekg(HEADER_SIZE, std::ios::beg);
}

void SldbReader::refill(size_t min_bytes) {
    if (buf_end_ - buf_pos_ >= min_bytes) return;

    // Move remaining data to front
    size_t remain = buf_end_ - buf_pos_;
    if (remain && buf_pos_) {
        std::memmove(buffer_.data(), buffer_.data() + buf_pos_, remain);
    }
    buf_pos_ = 0;
    buf_end_ = remain;

    size_t need = std::max(buffer_.size() - remain, min_bytes - remain);
    if (file_offset_ + remain >= file_size_) return;

    size_t to_read = std::min(need, static_cast<size_t>(file_size_ - file_offset_ - remain));
    if (to_read == 0) return;

    if (buf_end_ + to_read > buffer_.size()) {
        buffer_.resize(std::max(buffer_.size() * 2, buf_end_ + to_read));
    }

    file_.seekg(static_cast<std::streamoff>(file_offset_ + remain), std::ios::beg);
    file_.read(reinterpret_cast<char*>(buffer_.data() + buf_end_), static_cast<std::streamsize>(to_read));
    size_t got = static_cast<size_t>(file_.gcount());
    buf_end_ += got;
}

std::optional<Bytes> SldbReader::read_next_bytes() {
    if (record_no_ >= header_.record_count) {
        if (file_offset_ != file_size_)
            throw std::runtime_error("Corrupted SLDB — extra data after declared record count");
        return std::nullopt;
    }
    if (file_offset_ >= file_size_)
        throw std::runtime_error("Corrupted SLDB — unexpected EOF");

    // Read length (4 bytes LE)
    refill(4);
    if (buf_end_ - buf_pos_ < 4)
        throw std::runtime_error("Corrupted SLDB — incomplete record header");

    uint32_t len = read_u32_le(buffer_.data() + buf_pos_);
    buf_pos_ += 4;
    file_offset_ += 4;

    if (len > MAX_RECORD)
        throw std::runtime_error("Corrupted SLDB — record too large");
    if (len > file_size_ - file_offset_)
        throw std::runtime_error("Corrupted SLDB — record exceeds file");

    Bytes out(len);
    size_t written = 0;
    while (written < len) {
        refill(len - written);
        size_t avail = buf_end_ - buf_pos_;
        if (avail == 0)
            throw std::runtime_error("Corrupted SLDB — incomplete record");
        size_t take = std::min(avail, len - written);
        std::memcpy(out.data() + written, buffer_.data() + buf_pos_, take);
        buf_pos_ += take;
        file_offset_ += take;
        written += take;
    }

    ++record_no_;
    return out;
}

std::optional<std::string> SldbReader::read_next() {
    auto bytes = read_next_bytes();
    if (!bytes) return std::nullopt;
    std::string s(reinterpret_cast<const char*>(bytes->data()), bytes->size());
    if (!valid_utf8(s)) throw std::runtime_error("Corrupted SLDB — invalid UTF-8 record at index " + std::to_string(record_no_ - 1));
    return s;
}

bool SldbReader::skip_records(uint64_t count) {
    for (uint64_t i = 0; i < count; ++i) {
        if (!read_next_bytes()) return false;
    }
    return true;
}

} // namespace surasaki
