#include "dictionary_queue.hpp"
#include <filesystem>
#include <stdexcept>
#include <chrono>

namespace fs = std::filesystem;
namespace surasaki {

DictionaryQueue::DictionaryQueue(DictionarySession session, QueueConfig config)
    : session_(std::move(session)), config_(std::move(config)) {
    if (session_.active_index > session_.dictionaries.size())
        throw std::invalid_argument("session active_index is out of range");
    if (config_.runtime.workers == 0 || config_.runtime.batch_size == 0 || config_.runtime.queue_capacity == 0)
        throw std::invalid_argument("queue runtime configuration must be positive");
}

bool DictionaryQueue::find_next_selected(size_t from, size_t& index) const {
    for (size_t i = from; i < session_.dictionaries.size(); ++i) {
        if (session_.dictionaries[i].selected && session_.dictionaries[i].status != "completed") {
            index = i;
            return true;
        }
    }
    return false;
}

void DictionaryQueue::update_entry(size_t index, const std::string& status, uint64_t line, uint64_t total) {
    DictionarySessionEntry snapshot;
    {
        std::lock_guard<std::mutex> lock(state_mutex_);
        auto& e = session_.dictionaries.at(index);
        e.status = status;
        e.line = line;
        if (total != 0) e.total_lines = total;
        session_.active_index = index;
        session_.updated_at = static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::seconds>(std::chrono::system_clock::now().time_since_epoch()).count());
        snapshot = e;
    }
    if (config_.on_progress) config_.on_progress(snapshot);
}

QueueResult DictionaryQueue::run(const MatchTarget& target) {
    QueueResult qr;
    qr.state = QueueState::Running;
    stop_requested_ = false;
    session_.running = true;
    session_.last_error.clear();
    auto persist = [&]() {
        if (config_.session_store_path.empty()) return;
        DictionarySession snapshot;
        { std::lock_guard<std::mutex> lock(state_mutex_); snapshot = session_; }
        DictionarySessionStore store(config_.session_store_path);
        store.save(snapshot);
    };
    persist();

    size_t index = session_.active_index;
    if (index >= session_.dictionaries.size() || !session_.dictionaries[index].selected || session_.dictionaries[index].status == "completed") {
        if (!find_next_selected(0, index)) {
            session_.running = false;
            qr.state = QueueState::Completed;
            return qr;
        }
    }

    for (;;) {
        if (stop_requested_) { session_.running = false; qr.state = QueueState::Stopped; return qr; }
        auto& e = session_.dictionaries[index];
        if (!e.selected) { if (!find_next_selected(index + 1, index)) { qr.state = QueueState::Completed; session_.running=false; return qr; } continue; }
        if (config_.verify_signatures) {
            if (!fs::is_regular_file(e.path)) {
                update_entry(index, "failed", e.line, e.total_lines);
                qr.state=QueueState::Failed; qr.dictionary_index=index; qr.error="dictionary file is missing: "+e.path; session_.running=false; return qr;
            }
            const auto sig = dictionary_signature(e.path);
            if (!e.signature.empty() && sig != e.signature) {
                update_entry(index, "failed", e.line, e.total_lines);
                qr.state=QueueState::Failed; qr.dictionary_index=index; qr.error="dictionary signature changed: "+e.path; session_.running=false; return qr;
            }
            if (e.signature.empty()) e.signature=sig;
        }

        update_entry(index, "running", e.line, e.total_lines);
        RuntimeConfig rc = config_.runtime;
        rc.start_record = e.line;
        const uint64_t processed_base = session_.processed;
        const uint64_t skipped_base = session_.skipped;
        const uint64_t errors_base = session_.errors;
        const double elapsed_base = session_.elapsed_seconds;
        rc.on_progress = [this, index, processed_base, skipped_base, errors_base, elapsed_base, &persist](uint64_t line, uint64_t total, const Statistics& st) {
            DictionarySessionEntry entry;
            bool do_save = false;
            {
                std::lock_guard<std::mutex> lock(state_mutex_);
                auto& live = session_.dictionaries.at(index);
                live.line = line;
                live.total_lines = total;
                session_.processed = processed_base + st.processed_count();
                session_.skipped = skipped_base + st.skipped_count();
                session_.errors = errors_base + st.error_count();
                session_.elapsed_seconds = elapsed_base + st.elapsed();
                session_.rate = session_.elapsed_seconds > 0.0 ? static_cast<double>(session_.processed) / session_.elapsed_seconds : 0.0;
                session_.updated_at = static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::seconds>(std::chrono::system_clock::now().time_since_epoch()).count());
                entry = live;
                do_save = config_.autosave_interval_records && st.processed_count() > 0 && (st.processed_count() % config_.autosave_interval_records)==0;
            }
            if (config_.on_progress) config_.on_progress(entry);
            if (do_save) persist();
        };
        auto job = std::make_shared<DictionaryMatchJob>(e.path, target, rc);
        { std::lock_guard<std::mutex> lock(state_mutex_); active_job_ = job; }
        if (!job->start()) {
            { std::lock_guard<std::mutex> lock(state_mutex_); active_job_.reset(); } update_entry(index,"failed",e.line,e.total_lines);
            qr.state=QueueState::Failed; qr.dictionary_index=index; qr.error=job->error(); session_.running=false; return qr;
        }
        while (true) {
            bool stop=false, pause=false; { std::lock_guard<std::mutex> lock(state_mutex_); stop=stop_requested_; pause=pause_requested_; }
            if (stop) job->stop();
            if (pause) job->pause(); else job->resume();
            job->wait();
            break;
        }
        e.line = job->position();
        e.total_lines = job->total();
        session_.processed = processed_base + job->stats().processed_count();
        session_.errors = errors_base + job->stats().error_count();
        session_.skipped = skipped_base + job->stats().skipped_count();
        session_.elapsed_seconds = elapsed_base + job->stats().elapsed();
        session_.rate = session_.elapsed_seconds > 0.0 ? static_cast<double>(session_.processed) / session_.elapsed_seconds : 0.0;
        { std::lock_guard<std::mutex> lock(state_mutex_); active_job_.reset(); }
        if (job->state()==JobState::Found) {
            update_entry(index,"found",e.line,e.total_lines); session_.running=false; persist(); qr.state=QueueState::Found; qr.dictionary_index=index; qr.match=job->result(); session_.running=false; return qr;
        }
        if (job->state()==JobState::Stopped || stop_requested_) { update_entry(index,"paused",e.line,e.total_lines); session_.running=false; persist(); qr.state=QueueState::Stopped; qr.dictionary_index=index; session_.running=false; return qr; }
        if (job->state()==JobState::Failed) { update_entry(index,"failed",e.line,e.total_lines); session_.last_error=job->error(); session_.running=false; persist(); qr.state=QueueState::Failed; qr.dictionary_index=index; qr.error=job->error(); session_.running=false; return qr; }
        update_entry(index,"completed",e.line,e.total_lines); persist();
        if (!find_next_selected(index+1,index)) { session_.active_index=session_.dictionaries.size(); session_.running=false; qr.state=QueueState::Completed; qr.dictionary_index=e.selected?session_.dictionaries.size()-1:0; return qr; }
    }
}

void DictionaryQueue::request_pause() {
    std::shared_ptr<DictionaryMatchJob> job; { std::lock_guard<std::mutex> lock(state_mutex_); pause_requested_=true; job=active_job_; }
    if(job) job->pause();
}
void DictionaryQueue::request_resume() {
    std::shared_ptr<DictionaryMatchJob> job; { std::lock_guard<std::mutex> lock(state_mutex_); pause_requested_=false; job=active_job_; }
    if(job) job->resume();
}
void DictionaryQueue::request_stop() {
    std::shared_ptr<DictionaryMatchJob> job; { std::lock_guard<std::mutex> lock(state_mutex_); stop_requested_=true; job=active_job_; }
    if(job) job->stop();
}

bool DictionaryQueue::skip_current() {
    std::shared_ptr<DictionaryMatchJob> job;
    {
        std::lock_guard<std::mutex> lock(state_mutex_);
        if (session_.active_index >= session_.dictionaries.size()) return false;
        auto& e=session_.dictionaries[session_.active_index];
        e.status="skipped"; e.selected=false;
        ++session_.skipped;
        job=active_job_;
    }
    if(job) job->stop();
    return true;
}
bool DictionaryQueue::retry_current() {
    if (session_.active_index >= session_.dictionaries.size()) return false;
    auto& e=session_.dictionaries[session_.active_index];
    if(e.status!="failed" && e.status!="skipped") return false;
    e.selected=true; e.status="new"; return true;
}
void DictionaryQueue::reset() {
    request_stop();
    std::shared_ptr<DictionaryMatchJob> job;
    { std::lock_guard<std::mutex> lock(state_mutex_); job=active_job_; }
    if(job) job->wait();
    std::lock_guard<std::mutex> lock(state_mutex_);
    for(auto& e:session_.dictionaries){e.status="new";e.line=0;e.total_lines=0;}
    session_.active_index=0; session_.running=false; session_.processed=session_.skipped=session_.errors=0; session_.elapsed_seconds=session_.rate=0; session_.last_error.clear();
    pause_requested_=false; stop_requested_=false; active_job_.reset();
}

} // namespace surasaki
