#include "secp256k1_pure.hpp"
#include "crypto_engine.hpp"
#include <openssl/bn.h>
#include <openssl/ec.h>
#include <openssl/obj_mac.h>
#include <cstring>

namespace surasaki {

std::string derive_pub_hex(const Bytes& priv32, bool compressed) {
    if (priv32.size() != 32) return {};

    EC_GROUP* group = EC_GROUP_new_by_curve_name(NID_secp256k1);
    BN_CTX* ctx = BN_CTX_new();
    BIGNUM* priv = BN_bin2bn(priv32.data(), 32, nullptr);
    EC_POINT* pub = nullptr;
    std::string result;

    if (!group || !ctx || !priv || BN_is_zero(priv)) {
        EC_POINT_free(pub);
        BN_free(priv);
        BN_CTX_free(ctx);
        EC_GROUP_free(group);
        return {};
    }

    BIGNUM* order = BN_new();
    if (!order || EC_GROUP_get_order(group, order, ctx) != 1 ||
        BN_cmp(priv, order) >= 0) {
        BN_free(order);
        BN_free(priv);
        BN_CTX_free(ctx);
        EC_GROUP_free(group);
        return {};
    }

    pub = EC_POINT_new(group);
    if (!pub || EC_POINT_mul(group, pub, priv, nullptr, nullptr, ctx) != 1) {
        EC_POINT_free(pub);
        BN_free(order);
        BN_free(priv);
        BN_CTX_free(ctx);
        EC_GROUP_free(group);
        return {};
    }

    const point_conversion_form_t form = compressed
        ? POINT_CONVERSION_COMPRESSED
        : POINT_CONVERSION_UNCOMPRESSED;
    const size_t len = EC_POINT_point2oct(group, pub, form, nullptr, 0, ctx);
    if (len == (compressed ? 33U : 65U)) {
        Bytes out(len);
        if (EC_POINT_point2oct(group, pub, form, out.data(), out.size(), ctx) == len)
            result = to_hex(out);
    }

    EC_POINT_free(pub);
    BN_free(order);
    BN_free(priv);
    BN_CTX_free(ctx);
    EC_GROUP_free(group);
    return result;
}

CheckResult validate_ckey(const Bytes& master_key_32,
                          const Bytes& ckey_cipher,
                          const Bytes& pubkey) {
    if (master_key_32.size() != 32)
        return {CheckStatus::Invalid, "master key is not 32 bytes"};
    if (pubkey.size() != 33 && pubkey.size() != 65)
        return {CheckStatus::Invalid, "public key must be 33 or 65 bytes"};
    if (ckey_cipher.size() < 16 || (ckey_cipher.size() % 16) != 0)
        return {CheckStatus::Invalid, "ckey ciphertext length invalid"};

    // IV = first 16 bytes of SHA256(SHA256(pubkey))
    auto h1 = sha256(pubkey);
    auto h2 = sha256(h1);
    Bytes iv(h2.begin(), h2.begin() + 16);

    Bytes plain;
    try {
        plain = aes256_cbc_decrypt(master_key_32, iv, ckey_cipher);
    } catch (...) {
        return {CheckStatus::Invalid, "ckey AES decrypt failed"};
    }

    if (plain.size() != 32)
        return {CheckStatus::Invalid, "decrypted ckey is not 32 bytes"};

    // Range check against secp256k1 order
    BIGNUM* priv = BN_bin2bn(plain.data(), 32, nullptr);
    BIGNUM* n = nullptr;
    BN_hex2bn(&n, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141");
    if (!priv || !n || BN_is_zero(priv) || BN_cmp(priv, n) >= 0) {
        BN_free(priv);
        BN_free(n);
        return {CheckStatus::Invalid, "private key out of secp256k1 range"};
    }
    BN_free(n);
    BN_free(priv);

    std::string actual = derive_pub_hex(plain, pubkey.size() == 33);
    std::string expected = to_hex(pubkey);
    if (actual != expected)
        return {CheckStatus::Invalid, "decrypted private key does not match public key"};

    return {CheckStatus::Valid, "mkey + ckey + public key confirmed"};
}

} // namespace surasaki
