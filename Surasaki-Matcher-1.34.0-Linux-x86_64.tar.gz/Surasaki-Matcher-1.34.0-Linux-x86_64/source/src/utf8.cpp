#include "utf8.hpp"
namespace surasaki {
bool valid_utf8(std::string_view s){ size_t i=0; while(i<s.size()){ unsigned char c=s[i++]; if(c<0x80) continue; size_t n=0; unsigned cp=0; if((c&0xe0)==0xc0){n=1;cp=c&0x1f;if(cp<2)return false;} else if((c&0xf0)==0xe0){n=2;cp=c&0xf; } else if((c&0xf8)==0xf0){n=3;cp=c&7;if(cp>4)return false;} else return false; if(i+n>s.size())return false; for(size_t j=0;j<n;++j){unsigned char d=s[i++];if((d&0xc0)!=0x80)return false;cp=(cp<<6)|(d&0x3f);} if((n==2&&cp<0x800)||(n==3&&cp<0x10000)||cp>0x10ffff||(cp>=0xd800&&cp<=0xdfff))return false;} return true;}
size_t utf8_codepoints(std::string_view s){ if(!valid_utf8(s)) return 0; size_t n=0; for(unsigned char c:s) if((c&0xc0)!=0x80) ++n; return n; }
}
