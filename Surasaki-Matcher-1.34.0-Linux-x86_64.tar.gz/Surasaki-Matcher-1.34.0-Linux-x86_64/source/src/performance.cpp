#include "performance.hpp"
#include <algorithm>
#include <stdexcept>
#include <thread>
#include <system_error>
#include <fstream>
#include <string>
#include <limits>
namespace surasaki {
namespace {
size_t current_thread_count() {
    std::ifstream f("/proc/self/status");
    std::string k; size_t v=0;
    while (f >> k) {
        if (k == "Threads:") { f >> v; break; }
        std::string rest; std::getline(f, rest);
    }
    return v;
}
size_t cgroup_pids_budget() {
    std::ifstream maxf("/sys/fs/cgroup/pids.max");
    std::string maxs; if (!(maxf >> maxs) || maxs == "max") return std::numeric_limits<size_t>::max();
    try { return std::stoull(maxs); } catch (...) { return std::numeric_limits<size_t>::max(); }
}
size_t cgroup_pids_current() {
    std::ifstream f("/sys/fs/cgroup/pids.current"); size_t v=0; return (f >> v) ? v : 0;
}
}

size_t adaptive_worker_count(size_t requested, size_t hardware_threads) {
    const size_t hw = std::max<size_t>(1, hardware_threads ? hardware_threads : std::thread::hardware_concurrency());
    if (requested == 0) requested = hw;
    size_t budget = requested;
    const size_t pmax = cgroup_pids_budget();
    const size_t pcur = cgroup_pids_current();
    if (pmax != std::numeric_limits<size_t>::max() && pcur < pmax) budget = std::min(budget, pmax - pcur);
    const size_t self_threads = current_thread_count();
    if (self_threads && self_threads < budget) budget = std::min(budget, std::numeric_limits<size_t>::max() - self_threads);
    return std::max<size_t>(1, budget);
}

PerformanceSettings performance_settings(PerformanceProfile p,size_t hw){ hw=std::max<size_t>(1,hw); PerformanceSettings s; s.profile=p; switch(p){case PerformanceProfile::Eco:s.workers=1;s.batch_size=8;s.queue_capacity=32;s.progress_interval=256;break;case PerformanceProfile::Balanced:s.workers=hw;s.batch_size=32;s.queue_capacity=256;s.progress_interval=1024;break;case PerformanceProfile::Maximum:s.workers=std::max<size_t>(1,hw);s.batch_size=128;s.queue_capacity=1024;s.progress_interval=4096;break;} return s; }
PerformanceProfile parse_profile(const std::string& n){if(n=="eco"||n=="Эконом")return PerformanceProfile::Eco;if(n=="balanced"||n=="balance"||n=="Баланс")return PerformanceProfile::Balanced;if(n=="maximum"||n=="max"||n=="Максимум")return PerformanceProfile::Maximum;throw std::invalid_argument("unknown performance profile: "+n);}
const char* profile_name(PerformanceProfile p){switch(p){case PerformanceProfile::Eco:return "eco";case PerformanceProfile::Balanced:return "balanced";default:return "maximum";}}
}
