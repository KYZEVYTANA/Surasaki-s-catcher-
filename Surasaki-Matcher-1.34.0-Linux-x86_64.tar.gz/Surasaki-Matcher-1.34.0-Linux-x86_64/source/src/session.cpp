#include "session.hpp"
#include "utils.hpp"
#include <openssl/sha.h>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <stdexcept>
#include <chrono>
#include <cctype>
#include <algorithm>

namespace fs = std::filesystem;
namespace surasaki {
namespace {
std::string esc(const std::string& s) {
    std::ostringstream o;
    o << '"';
    for (unsigned char c : s) {
        switch (c) {
            case '"': o << "\\\""; break;
            case '\\': o << "\\\\"; break;
            case '\n': o << "\\n"; break;
            case '\r': o << "\\r"; break;
            case '\t': o << "\\t"; break;
            default:
                if (c < 0x20) o << "\\u00" << std::hex << std::setw(2) << std::setfill('0') << static_cast<unsigned>(c) << std::dec;
                else o << c;
        }
    }
    o << '"';
    return o.str();
}
size_t skip_ws(const std::string&s,size_t p){while(p<s.size()&&std::isspace((unsigned char)s[p]))++p;return p;}
size_t find_key(const std::string&s,const std::string&key){std::string needle="\""+key+"\"";size_t p=s.find(needle);if(p==std::string::npos)throw std::runtime_error("session JSON missing key: "+key);p=s.find(':',p+needle.size());if(p==std::string::npos)throw std::runtime_error("session JSON malformed key: "+key);return skip_ws(s,p+1);}
std::string str_at(const std::string&s,const std::string&k){size_t p=find_key(s,k);if(p>=s.size()||s[p]!='"')throw std::runtime_error("session JSON string expected: "+k);++p;std::string o;while(p<s.size()){char c=s[p++];if(c=='"')return o;if(c=='\\'){if(p>=s.size())throw std::runtime_error("session JSON bad escape");char e=s[p++];switch(e){case '"':o+='"';break;case '\\':o+='\\';break;case 'n':o+='\n';break;case 'r':o+='\r';break;case 't':o+='\t';break;default:throw std::runtime_error("session JSON unsupported escape");}}else o+=c;}throw std::runtime_error("session JSON unterminated string: "+k);}
uint64_t num_at(const std::string&s,const std::string&k){size_t p=find_key(s,k),e=p;while(e<s.size()&&(std::isdigit((unsigned char)s[e])))++e;if(e==p)throw std::runtime_error("session JSON number expected: "+k);return std::stoull(s.substr(p,e-p));}
double dbl_at(const std::string&s,const std::string&k){size_t p=find_key(s,k),e=p;while(e<s.size()&&(std::isdigit((unsigned char)s[e])||s[e]=='-'||s[e]=='+'||s[e]=='.'||s[e]=='e'||s[e]=='E'))++e;if(e==p)throw std::runtime_error("session JSON number expected: "+k);return std::stod(s.substr(p,e-p));}
bool bool_at(const std::string&s,const std::string&k){size_t p=find_key(s,k);if(s.compare(p,4,"true")==0)return true;if(s.compare(p,5,"false")==0)return false;throw std::runtime_error("session JSON boolean expected: "+k);}
std::string array_at(const std::string&s,const std::string&k){size_t p=find_key(s,k);if(p>=s.size()||s[p]!='[')throw std::runtime_error("session JSON array expected: "+k);size_t start=p,depth=0;bool quoted=false,escp=false;for(;p<s.size();++p){char c=s[p];if(quoted){if(escp)escp=false;else if(c=='\\')escp=true;else if(c=='"')quoted=false;}else if(c=='"')quoted=true;else if(c=='[')++depth;else if(c==']'){if(--depth==0)return s.substr(start,p-start+1);}}throw std::runtime_error("session JSON unterminated array: "+k);}
std::vector<std::string> objects(const std::string&a){std::vector<std::string> out;size_t p=1;while(p+1<a.size()){p=skip_ws(a,p);if(p>=a.size()-1)break;if(a[p]!= '{')throw std::runtime_error("session JSON dictionary object expected");size_t st=p,dep=0;bool q=false,es=false;for(;p<a.size();++p){char c=a[p];if(q){if(es)es=false;else if(c=='\\')es=true;else if(c=='"')q=false;}else if(c=='"')q=true;else if(c=='{')++dep;else if(c=='}'&&--dep==0){out.push_back(a.substr(st,p-st+1));++p;break;}}p=skip_ws(a,p);if(p<a.size()&&a[p]==',')++p;}return out;}
}
std::string dictionary_signature(const std::string& path){fs::path p(path);std::error_code ec;auto sz=fs::file_size(p,ec);if(ec)throw std::runtime_error("cannot stat dictionary: "+path);auto mt=fs::last_write_time(p,ec);if(ec)throw std::runtime_error("cannot stat dictionary timestamp: "+path);auto ticks=mt.time_since_epoch().count();std::string material; try { material=fs::weakly_canonical(p).string(); } catch (...) { material=p.lexically_normal().string(); } material+="|"+std::to_string(sz)+"|"+std::to_string(ticks);uint8_t h[SHA256_DIGEST_LENGTH];SHA256(reinterpret_cast<const unsigned char*>(material.data()),material.size(),h);return to_hex(h,SHA256_DIGEST_LENGTH);}
std::string session_to_json(const DictionarySession&s){std::ostringstream o;o<<"{\n  \"schema\": "<<s.schema<<",\n  \"session_id\": "<<esc(s.session_id)<<",\n  \"wallet_hash\": "<<esc(s.wallet_hash)<<",\n  \"target_mode\": "<<esc(s.target_mode)<<",\n  \"target\": "<<esc(s.target)<<",\n  \"created_at\": "<<s.created_at<<",\n  \"updated_at\": "<<s.updated_at<<",\n  \"workers\": "<<s.workers<<",\n  \"batch_size\": "<<s.batch_size<<",\n  \"queue_capacity\": "<<s.queue_capacity<<",\n  \"active_index\": "<<s.active_index<<",\n  \"running\": "<<(s.running?"true":"false")<<",\n  \"processed\": "<<s.processed<<",\n  \"skipped\": "<<s.skipped<<",\n  \"errors\": "<<s.errors<<",\n  \"elapsed_seconds\": "<<std::setprecision(17)<<s.elapsed_seconds<<",\n  \"rate\": "<<std::setprecision(17)<<s.rate<<",\n  \"last_error\": "<<esc(s.last_error)<<",\n  \"dictionaries\": [\n";for(size_t i=0;i<s.dictionaries.size();++i){auto&e=s.dictionaries[i];o<<"    {\"key\": "<<esc(e.key)<<", \"path\": "<<esc(e.path)<<", \"name\": "<<esc(e.name)<<", \"signature\": "<<esc(e.signature)<<", \"selected\": "<<(e.selected?"true":"false")<<", \"status\": "<<esc(e.status)<<", \"line\": "<<e.line<<", \"total_lines\": "<<e.total_lines<<"}"<<(i+1<s.dictionaries.size()?",":"")<<"\n";}o<<"  ]\n}\n";return o.str();}
DictionarySession session_from_json(const std::string&j){DictionarySession s;s.schema=(uint32_t)num_at(j,"schema");if(s.schema!=1)throw std::runtime_error("unsupported session schema");s.session_id=str_at(j,"session_id");s.wallet_hash=str_at(j,"wallet_hash");s.target_mode=str_at(j,"target_mode");s.target=str_at(j,"target");s.created_at=num_at(j,"created_at");s.updated_at=num_at(j,"updated_at");s.workers=(size_t)num_at(j,"workers");s.batch_size=(size_t)num_at(j,"batch_size");s.queue_capacity=(size_t)num_at(j,"queue_capacity");s.active_index=(size_t)num_at(j,"active_index");s.running=bool_at(j,"running");s.processed=num_at(j,"processed");s.skipped=num_at(j,"skipped");s.errors=num_at(j,"errors");s.elapsed_seconds=dbl_at(j,"elapsed_seconds");s.rate=dbl_at(j,"rate");s.last_error=str_at(j,"last_error");if(!s.workers||!s.batch_size||!s.queue_capacity)throw std::runtime_error("invalid session worker configuration");auto a=array_at(j,"dictionaries");for(const auto&o:objects(a)){DictionarySessionEntry e;e.key=str_at(o,"key");e.path=str_at(o,"path");e.name=str_at(o,"name");e.signature=str_at(o,"signature");e.selected=bool_at(o,"selected");e.status=str_at(o,"status");e.line=num_at(o,"line");e.total_lines=num_at(o,"total_lines");if(e.line>e.total_lines&&e.total_lines!=0)throw std::runtime_error("invalid dictionary checkpoint");s.dictionaries.push_back(std::move(e));}if(s.active_index>s.dictionaries.size())throw std::runtime_error("invalid active dictionary index");return s;}
bool save_session_json(const std::string&path,const DictionarySession&s){fs::path p(path);std::error_code ec;if(!p.parent_path().empty()){fs::create_directories(p.parent_path(),ec);if(ec)return false;}fs::path tmp=p.string()+".tmp";{std::ofstream f(tmp,std::ios::binary|std::ios::trunc);if(!f)return false;auto j=session_to_json(s);f.write(j.data(),(std::streamsize)j.size());f.flush();if(!f)return false;}fs::rename(tmp,p,ec);if(ec){fs::remove(p,ec);ec.clear();fs::rename(tmp,p,ec);}if(ec)fs::remove(tmp,ec);return !ec;}
DictionarySession load_session_json(const std::string&path){std::ifstream f(path,std::ios::binary);if(!f)throw std::runtime_error("cannot open session: "+path);std::ostringstream b;b<<f.rdbuf();return session_from_json(b.str());}
DictionarySessionStore::DictionarySessionStore(std::string p):path_(std::move(p)){}
void DictionarySessionStore::save(const DictionarySession&s)const{if(!save_session_json(path_,s))throw std::runtime_error("cannot save session: "+path_);}
DictionarySession DictionarySessionStore::load()const{return load_session_json(path_);}
bool DictionarySessionStore::exists()const{std::error_code ec;return fs::is_regular_file(path_,ec)&&!ec;}
void DictionarySessionStore::remove()const{std::error_code ec;fs::remove(path_,ec);if(ec)throw std::runtime_error("cannot remove session: "+path_);}
} // namespace surasaki
