#include "crypto_engine.hpp"
#include "sldb_reader.hpp"
#include "wallet_parser.hpp"
#include "generator.hpp"
#include "dictionary_engine.hpp"
#include "matcher_targets.hpp"
#include "runtime.hpp"
#include "progress.hpp"
#include "utils.hpp"
#include "session.hpp"
#include "dictionary_queue.hpp"
#include "performance.hpp"
#include "symbolic_runtime.hpp"
#include "console_ui.hpp"
#include "gpu.hpp"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <thread>
#include <filesystem>
#include <chrono>
#include <algorithm>
#include <openssl/crypto.h>
#include <unordered_set>
using namespace surasaki;
static void help(){std::cout<<R"(Surasaki Matcher — native Linux C++ port 1.34.0

Usage:
  surasaki-matcher self-test
  surasaki-matcher wallet inspect <wallet.dat>
  surasaki-matcher wallet verify <wallet.dat> --candidate STR
  surasaki-matcher sldb inspect <file.sldb>
  surasaki-matcher sldb scan <file.sldb> [--start N] [--limit N]
  surasaki-matcher sldb count <file.sldb>
  surasaki-matcher generate --alphabet STR --min N --max N [--start N] [--limit N]
  surasaki-matcher match exact --target STR [--no-trim] <file.sldb>
  surasaki-matcher match sha256 --target HEX64 <file.sldb>
  surasaki-matcher match wallet --target <wallet.dat> [--no-trim] <file.sldb>
  surasaki-matcher match-parallel exact --target STR [--no-trim] <file.sldb> [--workers N] [--batch N] [--queue N]
  surasaki-matcher match-parallel sha256 --target HEX64 <file.sldb> [--workers N] [--batch N] [--queue N]
  surasaki-matcher match-parallel wallet --target <wallet.dat> [--no-trim] <file.sldb> [--workers N] [--batch N] [--queue N]
  surasaki-matcher symbolic-match exact --target STR --alphabet STR --min N --max N [--start N] [--limit N] [--workers N] [--batch N]
  surasaki-matcher symbolic-match sha256 --target HEX64 --alphabet STR --min N --max N [--start N] [--limit N] [--workers N] [--batch N]
  surasaki-matcher symbolic-match wallet --target <wallet.dat> --alphabet STR --min N --max N [--start N] [--limit N] [--workers N] [--batch N]
  surasaki-matcher session create <file.json>
  surasaki-matcher session add <file.json> <dictionary.sldb>
  surasaki-matcher session remove <file.json> <index>
  surasaki-matcher session select <file.json> <index> <on|off>
  surasaki-matcher session list <file.json>
  surasaki-matcher session status <file.json>
  surasaki-matcher session run <file.json> --target STR [--mode exact|sha256|wallet] [--profile eco|balanced|maximum] [--no-trim]
  surasaki-matcher session reset <file.json>
  surasaki-matcher session recover <file.json>
  surasaki-matcher session export <file.json>
  surasaki-matcher session import <file.json>
  surasaki-matcher session signature <file.sldb>
  surasaki-matcher benchmark sldb <file.sldb> [--limit N]
  surasaki-matcher benchmark gpu [--limit N]
  surasaki-matcher benchmark generator --alphabet STR --min N --max N [--limit N]
  surasaki-matcher benchmark workers <file.sldb> [--workers N (any positive size_t)] [--limit N]
  surasaki-matcher diagnostics
  surasaki-matcher --help
  surasaki-matcher --version

All dictionary/session operations are local and offline. No network access is required.
)";}
static uint64_t arg_u64(int argc,char**a,const std::string&k,uint64_t d){for(int i=0;i+1<argc;++i)if(std::string(a[i])==k)return std::stoull(a[i+1]);return d;}
static std::string arg_s(int argc,char**a,const std::string&k,const std::string&d=""){for(int i=0;i+1<argc;++i)if(std::string(a[i])==k)return a[i+1];return d;}
static bool has_flag(int argc,char**a,const std::string&flag){for(int i=1;i<argc;++i)if(std::string(a[i])==flag)return true;return false;}
static MatchTarget target_from(const std::string&mode,const std::string&t,bool trim=true){
 if(mode=="exact") return MatchTarget{MatchMode::Exact,t,{},trim};
 if(mode=="sha256"){auto b=from_hex(t);if(b.size()!=32)throw std::runtime_error("SHA-256 target must be exactly 64 hex characters");return MatchTarget{MatchMode::Sha256,"",b,trim};}
 if(mode=="wallet"){
  if(t.empty()) throw std::runtime_error("wallet target path is required");
  std::string st;
  auto w=make_wallet_target_context(t,st);
  if(!w) throw std::runtime_error(st.empty()?"failed to load wallet target":st);
  MatchTarget mt;
  mt.mode=MatchMode::Wallet;
  mt.wallet=std::move(w);
  mt.normalize_trim=trim;
  return mt;
 }
 throw std::runtime_error("unknown match mode: "+mode);
}
static std::string positional_arg(int argc,char**a,int start){
 static const std::unordered_set<std::string> value_opts={"--target","--workers","--batch","--queue","--start","--limit","--profile","--mode","--alphabet","--min","--max"};
 std::string out;
 for(int i=start;i<argc;++i){ std::string x=a[i]; if(x.rfind("--",0)==0){ if(value_opts.count(x)&&i+1<argc) ++i; continue; } out=x; }
 return out;
}
static uint64_t now_epoch(){return (uint64_t)std::chrono::duration_cast<std::chrono::seconds>(std::chrono::system_clock::now().time_since_epoch()).count();}
static DictionarySession load_or_throw(const std::string&p){return load_session_json(p);}
int main(int argc,char**argv){try{
 if(argc<2){return run_console_ui(std::filesystem::absolute(argv[0]).parent_path());} std::string c=argv[1];
 if(c=="console"||c=="ui"){return run_console_ui(std::filesystem::absolute(argv[0]).parent_path());}
 if(c=="--help"||c=="-h"||c=="help"){help();return 0;}
 if(c=="--version"||c=="version"){std::cout<<"Surasaki Matcher 1.34.0\n";return 0;}
 if(c=="--self-test"||c=="self-test")return run_crypto_self_test(true)?0:1;
 if(c=="wallet"&&argc>=4&&std::string(argv[2])=="inspect"){std::string st;auto cfg=load_wallet_config(argv[3],st);std::cout<<st<<"\n";if(cfg)std::cout<<"Supported legacy structure detected.\n";return 0;}
 if(c=="wallet"&&argc>=5&&std::string(argv[2])=="verify"){
   std::string st; auto w=make_wallet_target_context(argv[3],st); std::cout<<st<<"\n";
   if(!w) return 2;
   auto cand=arg_s(argc,argv,"--candidate");
   if(cand.empty()) throw std::runtime_error("--candidate is required");
   MatchTarget t; t.mode=MatchMode::Wallet; t.wallet=std::move(w);
   bool ok=t.matches(cand);
   std::cout<<(ok?"VALID":"INVALID")<<"\n";
   return ok?0:2;
 }
 if(c=="sldb"&&argc>=4&&std::string(argv[2])=="inspect"){SldbReader r(argv[3]);r.open();std::cout<<"SLDB v"<<(int)r.header().version<<" records="<<r.header().record_count<<"\n";for(int i=0;i<5;++i){auto s=r.read_next();if(!s)break;std::cout<<"["<<i<<"] "<<s->substr(0,std::min<size_t>(80,s->size()))<<(s->size()>80?"…":"")<<"\n";}return 0;}
 if(c=="sldb"&&argc>=4&&std::string(argv[2])=="scan"){uint64_t start=arg_u64(argc,argv,"--start",0),limit=arg_u64(argc,argv,"--limit",100);DictionaryEngine e(argv[3]);e.open();if(start&&!e.seek(start))throw std::runtime_error("start beyond EOF");std::string x;uint64_t n=0;while(n<limit&&e.next(x)){++n;std::cout<<start+n-1<<"\t"<<x<<"\n";}std::cerr<<"processed="<<e.stats().processed_count()<<" rate="<<e.stats().rate()<<" rec/s\n";return 0;}
 if(c=="sldb"&&argc>=4&&std::string(argv[2])=="count"){SldbReader r(argv[3]);r.open();uint64_t n=0;while(r.read_next())++n;std::cout<<"records="<<n<<"\n";return 0;}
 if(c=="generate"){std::string alpha=arg_s(argc,argv,"--alphabet");unsigned mn=(unsigned)arg_u64(argc,argv,"--min",1),mx=(unsigned)arg_u64(argc,argv,"--max",mn);uint64_t lim=arg_u64(argc,argv,"--limit",100);SymbolicGenerator g({alpha,mn,mx});std::string start=arg_s(argc,argv,"--start");if(!start.empty())g.seek(BigInt(start));for(uint64_t i=0;i<lim;++i){auto s=g.next();if(!s)break;std::cout<<*s<<"\n";}std::cerr<<"index="<<g.index()<<" total="<<g.total()<<" progress="<<percent(g.index(),g.total())<<"%\n";return 0;}
 if(c=="match"&&argc>=5){auto t=target_from(argv[2],arg_s(argc,argv,"--target"),!has_flag(argc,argv,"--no-trim"));std::string path=positional_arg(argc,argv,3);if(path.empty())throw std::runtime_error("dictionary path is required");SldbReader r(path);r.open();uint64_t n=0;while(auto s=r.read_next()){if(t.matches(*s)){std::cout<<"MATCH record="<<n<<" value="<<*s<<"\n";return 0;}++n;}std::cout<<"No match\n";return 2;}
 if(c=="match-parallel"&&argc>=5){auto t=target_from(argv[2],arg_s(argc,argv,"--target"),!has_flag(argc,argv,"--no-trim"));RuntimeConfig rc;rc.workers=adaptive_worker_count(arg_u64(argc,argv,"--workers",0));rc.batch_size=arg_u64(argc,argv,"--batch",32);rc.queue_capacity=arg_u64(argc,argv,"--queue",256);std::string path=positional_arg(argc,argv,3);if(path.empty())throw std::runtime_error("dictionary path is required");DictionaryMatchJob job(path,t,rc);if(!job.start())throw std::runtime_error(job.error());job.wait();if(auto r=job.result()){std::cout<<"MATCH record="<<r->record<<" value="<<r->candidate<<"\n";return 0;}if(job.state()==JobState::Completed){std::cout<<"No match\n";return 2;}throw std::runtime_error(job.error().empty()?"parallel match failed":job.error());}
 if(c=="symbolic-match"&&argc>=5){auto t=target_from(argv[2],arg_s(argc,argv,"--target"),!has_flag(argc,argv,"--no-trim"));GeneratorConfig gc{arg_s(argc,argv,"--alphabet"),(unsigned)arg_u64(argc,argv,"--min",1),(unsigned)arg_u64(argc,argv,"--max",1)};SymbolicRunConfig sc;sc.start=arg_u64(argc,argv,"--start",0);sc.limit=arg_u64(argc,argv,"--limit",0);sc.workers=arg_u64(argc,argv,"--workers",std::min<size_t>(4,std::max(1u,std::thread::hardware_concurrency())));sc.batch_size=arg_u64(argc,argv,"--batch",32);auto r=run_symbolic_match(gc,t,sc);if(r.found){std::cout<<"MATCH index="<<r.index<<" value="<<r.candidate<<"\n";return 0;}std::cout<<"No match; processed="<<r.processed<<"\n";return 2;}
 if(c=="session"&&argc>=4){std::string op=argv[2],path=argv[3];
   if(op=="signature"){std::cout<<dictionary_signature(path)<<"\n";return 0;}
   if(op=="create"){DictionarySession s;s.schema=1;s.session_id=std::to_string(now_epoch());s.created_at=s.updated_at=now_epoch();auto ps=performance_settings(PerformanceProfile::Balanced,std::thread::hardware_concurrency());s.workers=adaptive_worker_count(ps.workers);s.batch_size=ps.batch_size;s.queue_capacity=ps.queue_capacity;s.target_mode="exact";s.active_index=0;if(!save_session_json(path,s))throw std::runtime_error("cannot create session");std::cout<<"Created "<<path<<"\n";return 0;}
   auto s=load_or_throw(path);
   if(op=="add"&&argc>=5){DictionarySessionEntry e;e.path=argv[4];e.name=std::filesystem::path(e.path).filename().string();e.key=std::to_string(s.dictionaries.size());e.signature=dictionary_signature(e.path);e.selected=true;e.status="new";SldbReader r(e.path);r.open();e.total_lines=r.header().record_count;s.dictionaries.push_back(e);s.updated_at=now_epoch();if(!save_session_json(path,s))throw std::runtime_error("cannot save session");std::cout<<"Added index="<<s.dictionaries.size()-1<<"\n";return 0;}
   if(op=="remove"&&argc>=5){size_t i=std::stoull(argv[4]);if(i>=s.dictionaries.size())throw std::runtime_error("index out of range");s.dictionaries.erase(s.dictionaries.begin()+i);for(size_t j=0;j<s.dictionaries.size();++j)s.dictionaries[j].key=std::to_string(j);if(s.active_index>i&&s.active_index)s.active_index--;else if(s.active_index>=s.dictionaries.size())s.active_index=s.dictionaries.size();if(!save_session_json(path,s))throw std::runtime_error("cannot save session");return 0;}
   if(op=="select"&&argc>=6){size_t i=std::stoull(argv[4]);if(i>=s.dictionaries.size())throw std::runtime_error("index out of range");std::string v=argv[5];if(v!="on"&&v!="off")throw std::runtime_error("select expects on|off");s.dictionaries[i].selected=(v=="on");if(!save_session_json(path,s))throw std::runtime_error("cannot save session");return 0;}
   if(op=="list"){for(size_t i=0;i<s.dictionaries.size();++i){auto&e=s.dictionaries[i];std::cout<<i<<"\t"<<(e.selected?"on":"off")<<"\t"<<e.status<<"\t"<<e.line<<"/"<<e.total_lines<<"\t"<<e.path<<"\n";}return 0;}
   if(op=="status"){std::cout<<"session="<<s.session_id<<" running="<<(s.running?"yes":"no")<<" active="<<s.active_index<<" dictionaries="<<s.dictionaries.size()<<" processed="<<s.processed<<" skipped="<<s.skipped<<" errors="<<s.errors<<" rate="<<s.rate<<"\n";return 0;}
   if(op=="recover"){for(auto&e:s.dictionaries)if(e.status=="running")e.status="paused";s.running=false;s.updated_at=now_epoch();if(!save_session_json(path,s))throw std::runtime_error("cannot save recovered session");std::cout<<"Session marked recoverable; next run resumes from committed records.\n";return 0;}
   if(op=="reset"){for(auto&e:s.dictionaries){e.status="new";e.line=0;}s.active_index=0;s.processed=s.skipped=s.errors=0;s.elapsed_seconds=s.rate=0;s.last_error.clear();s.running=false;if(!save_session_json(path,s))throw std::runtime_error("cannot save session");return 0;}
   if(op=="export"||op=="import"){auto loaded=load_session_json(path);std::cout<<session_to_json(loaded);return 0;}
   if(op=="run"){std::string mode=arg_s(argc,argv,"--mode",s.target_mode.empty()?"exact":s.target_mode);std::string target=arg_s(argc,argv,"--target",s.target);if(target.empty())throw std::runtime_error("--target is required");s.target_mode=mode;s.target=target;auto prof=parse_profile(arg_s(argc,argv,"--profile","balanced"));auto ps=performance_settings(prof,std::thread::hardware_concurrency());s.workers=adaptive_worker_count(ps.workers);s.batch_size=ps.batch_size;s.queue_capacity=ps.queue_capacity;QueueConfig qc;qc.runtime.workers=s.workers;qc.runtime.batch_size=s.batch_size;qc.runtime.queue_capacity=s.queue_capacity;qc.autosave_interval_records=ps.progress_interval;qc.session_store_path=path;qc.on_progress=[](const DictionarySessionEntry&e){std::cerr<<"\r"<<e.name<<" "<<e.line<<"/"<<e.total_lines<<std::flush;};auto t=target_from(mode,target,!has_flag(argc,argv,"--no-trim"));DictionaryQueue q(s,qc);auto r=q.run(t);std::cerr<<"\n";auto final=q.snapshot();if(!save_session_json(path,final))throw std::runtime_error("cannot save final session");if(r.match)std::cout<<"MATCH record="<<r.match->record<<" value="<<r.match->candidate<<"\n";else if(r.state==QueueState::Completed)std::cout<<"Queue completed\n";else std::cout<<"Queue state="<<(int)r.state<<" error="<<r.error<<"\n";return r.state==QueueState::Completed||r.state==QueueState::Found?0:1;}
 }
 if(c=="benchmark"&&argc>=4&&std::string(argv[2])=="sldb"){uint64_t lim=arg_u64(argc,argv,"--limit",100000);SldbReader r(argv[3]);r.open();auto t=now_sec();uint64_t n=0,bytes=0;while(n<lim){auto s=r.read_next();if(!s)break;bytes+=s->size();++n;}double sec=now_sec()-t;std::cout<<"records="<<n<<" bytes="<<bytes<<" seconds="<<sec<<" records/sec="<<(sec?n/sec:0)<<" MB/sec="<<(sec?bytes/sec/1e6:0)<<"\n";return 0;}
 if(c=="benchmark"&&argc>=4&&std::string(argv[2])=="generator"){SymbolicGenerator g({arg_s(argc,argv,"--alphabet"),(unsigned)arg_u64(argc,argv,"--min",1),(unsigned)arg_u64(argc,argv,"--max",1)});uint64_t lim=arg_u64(argc,argv,"--limit",100000);auto t=now_sec();uint64_t n=0;while(n<lim&&g.next())++n;double sec=now_sec()-t;std::cout<<"candidates="<<n<<" seconds="<<sec<<" candidates/sec="<<(sec?n/sec:0)<<"\n";return 0;}
 if(c=="benchmark"&&argc>=3&&std::string(argv[2])=="gpu"){auto r=benchmark_gpu_sha256(arg_u64(argc,argv,"--limit",8192));if(!r.available){std::cout<<"GPU unavailable: "<<r.reason<<"\n";return 2;}std::cout<<"device="<<r.device<<" candidates="<<r.candidates<<" seconds="<<r.seconds<<" candidates/sec="<<r.candidates_per_second<<"\n";return 0;}
 if(c=="benchmark"&&argc>=4&&std::string(argv[2])=="workers"){uint64_t lim=arg_u64(argc,argv,"--limit",100000);size_t maxw=arg_u64(argc,argv,"--workers",std::max<size_t>(1,std::thread::hardware_concurrency()));for(size_t w=1;w<=maxw;++w){RuntimeConfig rc;rc.workers=w;rc.batch_size=32;rc.queue_capacity=256;MatchTarget t{MatchMode::Exact,"\x01never-match",{}};std::string path=positional_arg(argc,argv,3);if(path.empty())throw std::runtime_error("dictionary path is required");DictionaryMatchJob j(path,t,rc);auto t0=now_sec();if(!j.start())throw std::runtime_error(j.error());j.wait();double sec=now_sec()-t0;std::cout<<"workers="<<w<<" seconds="<<sec<<" rate="<<(sec?j.stats().processed_count()/sec:0)<<" records/sec\n";if(j.stats().processed_count()>=lim)break;}return 0;}
 if(c=="diagnostics"){auto g=detect_gpu();std::cout<<"Surasaki Matcher 1.34.0\nC++20\nOpenSSL: "<<OpenSSL_version(OPENSSL_VERSION)<<"\nHardware threads: "<<std::thread::hardware_concurrency()<<"\nAuto workers: "<<adaptive_worker_count(0)<<"\nOffline mode: yes\nGPU backend: "<<(g.available?"available":"unavailable")<<"\n"<<(g.available?("GPU device: "+g.device):("GPU reason: "+g.reason))<<"\n";return 0;}
 help();return 1;
 }catch(const std::exception&e){std::cerr<<"ERROR: "<<e.what()<<"\n";return 1;}}
