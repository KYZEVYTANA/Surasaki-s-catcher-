#include "matcher_targets.hpp"
#include "crypto_engine.hpp"
#include "utf8.hpp"
#include <stdexcept>
#include <cstdint>

namespace surasaki {
namespace {
uint32_t cp_at(const std::string& s,size_t p,size_t& n){
    const unsigned char c=static_cast<unsigned char>(s[p]); n=1;
    if(c<0x80) return c;
    if((c&0xE0)==0xC0){n=2;return ((c&0x1F)<<6)|(static_cast<unsigned char>(s[p+1])&0x3F);}
    if((c&0xF0)==0xE0){n=3;return ((c&0x0F)<<12)|((static_cast<unsigned char>(s[p+1])&0x3F)<<6)|(static_cast<unsigned char>(s[p+2])&0x3F);}
    n=4;return ((c&7)<<18)|((static_cast<unsigned char>(s[p+1])&0x3F)<<12)|((static_cast<unsigned char>(s[p+2])&0x3F)<<6)|(static_cast<unsigned char>(s[p+3])&0x3F);
}
bool ws(uint32_t c){return (c>=0x9&&c<=0xD)||c==0x20||c==0xA0||c==0x1680||(c>=0x2000&&c<=0x200A)||c==0x2028||c==0x2029||c==0x202F||c==0x205F||c==0x3000||c==0xFEFF;}
std::string trim_js(std::string_view s){
    if(!valid_utf8(s)) return std::string(s);
    size_t a=0,b=s.size();
    while(a<b){size_t n=0;uint32_t c=cp_at(std::string(s),a,n);if(!ws(c))break;a+=n;}
    while(b>a){size_t q=b-1;while(q>a&&(static_cast<unsigned char>(s[q])&0xC0)==0x80)--q;size_t n=0;uint32_t c=cp_at(std::string(s),q,n);if(!ws(c))break;b=q;}
    return std::string(s.substr(a,b-a));
}
}
bool MatchTarget::matches(const std::string&candidate)const{
    if(mode==MatchMode::Exact){
        const std::string c=this->normalize_trim?trim_js(candidate):candidate;
        const std::string t=this->normalize_trim?trim_js(exact):exact;
        return c==t;
    }
    if(mode==MatchMode::Sha256){
        Bytes b(candidate.begin(),candidate.end());
        return sha256(b)==sha256_target;
    }
    if(mode==MatchMode::Wallet){
        if(!wallet) throw std::runtime_error("wallet target context is not configured");
        const auto r=check_wallet_candidate(candidate,wallet->config);
        if(r.status==CheckStatus::Unknown) throw std::runtime_error(r.reason.empty()?"wallet verification returned UNKNOWN":r.reason);
        return r.status==CheckStatus::Valid;
    }
    throw std::runtime_error("unsupported match mode");
}
} // namespace surasaki
