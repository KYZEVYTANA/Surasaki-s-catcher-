#include "wallet_parser.hpp"
#include "crypto_engine.hpp"
#include <fstream>
#include <cstring>
#include <map>
#include <filesystem>
#include <iomanip>
#include <sstream>

namespace surasaki {

static size_t compact_size_read(const uint8_t* a, size_t len, size_t& pos) {
    if (pos >= len) throw std::runtime_error("CompactSize: unexpected end");
    uint8_t x = a[pos++];
    if (x < 253) return x;
    if (x == 253) {
        if (pos + 2 > len) throw std::runtime_error("CompactSize truncated");
        uint16_t v = read_u16_le(a + pos);
        pos += 2;
        return v;
    }
    if (x == 254) {
        if (pos + 4 > len) throw std::runtime_error("CompactSize truncated");
        uint32_t v = read_u32_le(a + pos);
        pos += 4;
        return v;
    }
    throw std::runtime_error("CompactSize uint64 not supported by this parser");
}

ParsedWallet parse_bitcoin_wallet_dat(const Bytes& data) {
    ParsedWallet result;
    if (data.size() < 96)
        throw std::runtime_error("File too small for Berkeley DB wallet.dat");

    const uint8_t* a = data.data();
    uint32_t magic   = read_u32_le(a + 12);
    uint32_t version = read_u32_le(a + 16);
    uint32_t page_size = read_u32_le(a + 20);

    if (magic != 0x00053162)
        throw std::runtime_error("Not a recognised Berkeley DB wallet.dat (bad magic)");
    if (page_size < 512 || page_size > 1048576 || (page_size & (page_size - 1)) != 0)
        throw std::runtime_error("Invalid Berkeley DB page size");
    if (data.size() % page_size != 0)
        throw std::runtime_error("wallet.dat size not multiple of page size");

    result.analysis.format = "Berkeley DB wallet";
    result.analysis.db_version = version;
    result.analysis.page_size = page_size;
    result.analysis.page_count = data.size() / page_size;

    std::map<std::string, size_t> record_types;
    size_t page_count = result.analysis.page_count;

    for (size_t page_no = 1; page_no < page_count; ++page_no) {
        const uint8_t* page = a + page_no * page_size;
        if (read_u32_le(page + 8) != page_no) continue;
        uint8_t type = page[25];
        if (type != 5 && type != 13) continue;
        uint16_t entries = read_u16_le(page + 20);
        if (!entries || (entries & 1)) continue;
        if (26u + static_cast<uint32_t>(entries) * 2u > page_size) continue;

        std::vector<uint16_t> offs(entries);
        bool valid = true;
        for (uint16_t i = 0; i < entries; ++i) {
            uint16_t o = read_u16_le(page + 26 + i * 2);
            if (o < 26 || o >= page_size) { valid = false; break; }
            offs[i] = o;
        }
        if (!valid) continue;

        for (uint16_t i = 0; i + 1 < entries; i += 2) {
            // key item
            uint16_t koff = offs[i];
            if (static_cast<uint32_t>(koff) + 3u > page_size) continue;
            uint16_t klen = read_u16_le(page + koff);
            uint8_t ktype = page[koff + 2] & 0x7f;
            bool kdel = (page[koff + 2] & 0x80) != 0;
            if (ktype != 1 || kdel || static_cast<uint32_t>(koff) + 3u + klen > page_size) continue;
            const uint8_t* kd = page + koff + 3;

            // data item
            uint16_t doff = offs[i + 1];
            if (static_cast<uint32_t>(doff) + 3u > page_size) continue;
            uint16_t dlen = read_u16_le(page + doff);
            uint8_t dtype = page[doff + 2] & 0x7f;
            bool ddel = (page[doff + 2] & 0x80) != 0;
            if (dtype != 1 || ddel || static_cast<uint32_t>(doff) + 3u + dlen > page_size) continue;
            const uint8_t* dd = page + doff + 3;

            size_t pos = 0;
            size_t key_len = 0;
            try {
                key_len = compact_size_read(kd, klen, pos);
            } catch (...) { continue; }
            if (key_len > 128 || pos + key_len > klen) continue;

            std::string key_type(reinterpret_cast<const char*>(kd + pos), key_len);
            pos += key_len;
            record_types[key_type]++;

            if (key_type == "mkey") {
                if (pos + 4 > klen) continue;
                uint32_t id = read_u32_le(kd + pos);
                size_t q = 0;
                size_t cipher_len = 0;
                try {
                    cipher_len = compact_size_read(dd, dlen, q);
                } catch (...) { continue; }
                if (cipher_len < 16 || cipher_len > 4096 || q + cipher_len > dlen) continue;
                Bytes cipher(dd + q, dd + q + cipher_len);
                q += cipher_len;
                size_t salt_len = 0;
                try {
                    salt_len = compact_size_read(dd, dlen, q);
                } catch (...) { continue; }
                if (salt_len != 8 || q + 8 + 8 > dlen) continue;
                Bytes salt(dd + q, dd + q + 8);
                q += 8;
                uint32_t method = read_u32_le(dd + q); q += 4;
                uint32_t iter   = read_u32_le(dd + q);
                MKey mk{id, std::move(cipher), std::move(salt), method, iter};
                result.mkeys.push_back(mk);
            } else if (key_type == "ckey" || key_type == "ckeyA") {
                size_t pub_len = 0;
                try {
                    pub_len = compact_size_read(kd, klen, pos);
                } catch (...) { continue; }
                if ((pub_len != 33 && pub_len != 65) || pos + pub_len > klen) continue;
                Bytes pub(kd + pos, kd + pos + pub_len);
                size_t q = 0;
                size_t cipher_len = 0;
                try {
                    cipher_len = compact_size_read(dd, dlen, q);
                } catch (...) { continue; }
                if (cipher_len < 16 || cipher_len > 4096 || q + cipher_len > dlen) continue;
                CKey ck;
                ck.pub = std::move(pub);
                ck.cipher.assign(dd + q, dd + q + cipher_len);
                ck.type = key_type;
                if (key_type == "ckey") result.ckeys.push_back(std::move(ck));
                else result.ckey_as.push_back(std::move(ck));
            } else if (key_type == "hdchain") {
                result.analysis.hdchain_count++;
            } else if (key_type == "key") {
                result.analysis.key_count++;
            }
        }
    }

    result.analysis.mkey_count = result.mkeys.size();
    result.analysis.ckey_count = result.ckeys.size();
    result.analysis.ckey_a_count = result.ckey_as.size();
    result.analysis.encryption = result.mkeys.empty()
        ? (result.ckeys.empty() && result.ckey_as.empty() ? "not detected" : "encrypted-key records detected")
        : "master-key records detected";

    if (result.mkeys.size() == 1 && !result.ckeys.empty() && result.mkeys[0].method == 0)
        result.analysis.compatibility = "supported existing legacy handler";
    else if (result.mkeys.size() > 1)
        result.analysis.compatibility = "manual mkey selection required";
    else
        result.analysis.compatibility = "partially detected; crypto scheme not fully supported";

    if (!result.mkeys.empty()) {
        result.mkey = result.mkeys[0];
    }

    return result;
}

std::string render_wallet_analysis(const WalletAnalysis& a) {
    std::ostringstream oss;
    oss << "Wallet Analyzer\n"
        << "Format: " << a.format << "\n"
        << "BDB version: " << a.db_version << " • page: " << a.page_size << "\n"
        << "Encryption: " << a.encryption << "\n"
        << "mkey: " << a.mkey_count << "\n"
        << "ckey: " << a.ckey_count << " • ckeyA: " << a.ckey_a_count << "\n"
        << "hdchain: " << a.hdchain_count << " • key: " << a.key_count << "\n"
        << "Compatibility: " << a.compatibility;
    return oss.str();
}

std::optional<WalletConfig> load_wallet_config(const std::string& path, std::string& status_msg) {
    std::ifstream f(path, std::ios::binary);
    if (!f) {
        status_msg = "Cannot open file: " + path;
        return std::nullopt;
    }
    f.seekg(0, std::ios::end);
    size_t sz = static_cast<size_t>(f.tellg());
    f.seekg(0, std::ios::beg);
    Bytes data(sz);
    f.read(reinterpret_cast<char*>(data.data()), static_cast<std::streamsize>(sz));

    try {
        auto parsed = parse_bitcoin_wallet_dat(data);
        status_msg = render_wallet_analysis(parsed.analysis);

        if (!parsed.mkey || parsed.ckeys.empty()) {
            status_msg += "\n⚠ Format recognised but current verifier does not support this structure.";
            return std::nullopt;
        }
        if (parsed.mkeys.size() != 1) {
            status_msg += "\n⚠ Multiple mkey found — automatic selection disabled.";
            return std::nullopt;
        }
        if (parsed.mkey->method != 0) {
            status_msg += "\n⚠ nDerivationMethod=" + std::to_string(parsed.mkey->method) + " not supported.";
            return std::nullopt;
        }

        WalletConfig cfg;
        cfg.mkey_cipher = parsed.mkey->cipher;
        cfg.salt = parsed.mkey->salt;
        cfg.iterations = static_cast<int>(parsed.mkey->iterations);
        cfg.ckey_cipher = parsed.ckeys[0].cipher;
        cfg.pubkey = parsed.ckeys[0].pub;
        return cfg;
    } catch (const std::exception& e) {
        status_msg = std::string("Parse error: ") + e.what();
        return std::nullopt;
    }
}

std::shared_ptr<const WalletTargetContext> make_wallet_target_context(const std::string& path, std::string& status_msg) {
    auto cfg = load_wallet_config(path, status_msg);
    if (!cfg) return {};
    auto ctx = std::make_shared<WalletTargetContext>();
    ctx->config = std::move(*cfg);
    std::error_code ec;
    const auto canonical = std::filesystem::weakly_canonical(path, ec);
    const auto id_path = ec ? std::filesystem::absolute(path, ec).string() : canonical.string();
    std::ostringstream id;
    id << id_path;
    std::error_code sec;
    const auto sz = std::filesystem::file_size(path, sec);
    if (!sec) id << "|size=" << sz;
    ctx->wallet_identity = id.str();
    return ctx;
}

} // namespace surasaki
