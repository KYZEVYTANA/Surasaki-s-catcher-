#include "progress.hpp"
namespace surasaki { double percent(uint64_t c,uint64_t t){return !t?0.0:(c>=t?100.0:(double)c*100.0/(double)t);} double percent(const BigInt&c,const BigInt&t){if(t<=0)return 0; if(c<=0)return 0; if(c>=t)return 100; BigInt scaled=(c*1000000)/t; return scaled.convert_to<double>()/10000.0;} }
