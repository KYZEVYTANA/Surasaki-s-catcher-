#include "checkpoint.hpp"
#include <filesystem>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <cctype>
#include <system_error>

namespace fs = std::filesystem;

namespace surasaki {
namespace {
std::string safe_component(std::string s) {
    if (s.empty()) return "empty";
    for (char& c : s) {
        const unsigned char u = static_cast<unsigned char>(c);
        if (!(std::isalnum(u) || c == '_' || c == '-' || c == '.')) c = '_';
    }
    return s;
}

bool atomic_write(const fs::path& final_path, const std::string& data) {
    std::error_code ec;
    const auto parent = final_path.parent_path();
    if (!parent.empty()) { fs::create_directories(parent, ec); if (ec) return false; }
    const fs::path tmp = final_path.string() + ".tmp";
    {
        std::ofstream f(tmp, std::ios::binary | std::ios::trunc);
        if (!f) return false;
        f.write(data.data(), static_cast<std::streamsize>(data.size()));
        f.flush();
        if (!f) return false;
    }
    fs::rename(tmp, final_path, ec);
    if (ec) {
        fs::remove(final_path, ec);
        ec.clear();
        fs::rename(tmp, final_path, ec);
    }
    if (ec) fs::remove(tmp, ec);
    return !ec;
}
}

CheckpointStore::CheckpointStore(const std::string& dir) : dir_(dir) {
    std::error_code ec;
    fs::create_directories(dir_, ec);
}

void CheckpointStore::set_session_prefix(const std::string& wallet_hash) {
    prefix_ = "scope_" + safe_component(wallet_hash) + "_";
}

std::string CheckpointStore::path_for(const std::string& name) const {
    return (fs::path(dir_) / (prefix_ + safe_component(name) + ".txt")).string();
}

bool CheckpointStore::save_dict(const DictCheckpoint& e) {
    std::ostringstream out;
    out << e.key << '\n' << e.name << '\n' << (e.selected ? 1 : 0) << '\n'
        << e.status << '\n' << std::setprecision(17) << e.progress << '\n'
        << e.line << '\n' << e.total_lines << '\n' << e.last_checkpoint << '\n';
    return atomic_write(path_for("dict_" + e.key), out.str());
}

std::optional<DictCheckpoint> CheckpointStore::load_dict(const std::string& key) {
    std::ifstream f(path_for("dict_" + key), std::ios::binary);
    if (!f) return std::nullopt;
    DictCheckpoint e;
    int sel = 0;
    if (!std::getline(f, e.key) || !std::getline(f, e.name)) return std::nullopt;
    if (!(f >> sel >> e.status >> e.progress >> e.line >> e.total_lines >> e.last_checkpoint)) return std::nullopt;
    if (e.key != key || (sel != 0 && sel != 1) || e.progress < 0.0 || e.progress > 100.0) return std::nullopt;
    e.selected = sel != 0;
    return e;
}

bool CheckpointStore::save_brute(const BruteCheckpoint& b) {
    std::ostringstream out;
    out << b.idx << '\n' << b.len << '\n' << std::setprecision(17) << b.progress << '\n' << b.timestamp << '\n';
    return atomic_write(path_for("brute"), out.str());
}

std::optional<BruteCheckpoint> CheckpointStore::load_brute() {
    std::ifstream f(path_for("brute"), std::ios::binary);
    if (!f) return std::nullopt;
    BruteCheckpoint b;
    if (!(f >> b.idx >> b.len >> b.progress >> b.timestamp)) return std::nullopt;
    if (b.len < 1 || b.progress < 0.0 || b.progress > 100.0) return std::nullopt;
    return b;
}

bool CheckpointStore::save_found(const FoundState& s) {
    std::ostringstream out;
    out << (s.found ? 1 : 0) << '\n' << s.candidate << '\n' << s.source << '\n' << s.timestamp << '\n';
    return atomic_write(path_for("found"), out.str());
}

std::optional<FoundState> CheckpointStore::load_found() {
    std::ifstream f(path_for("found"), std::ios::binary);
    if (!f) return std::nullopt;
    FoundState s;
    int found = 0;
    if (!(f >> found)) return std::nullopt;
    f.ignore(1, '\n');
    if (!std::getline(f, s.candidate) || !std::getline(f, s.source) || !(f >> s.timestamp)) return std::nullopt;
    if (found != 0 && found != 1) return std::nullopt;
    s.found = found != 0;
    return s;
}

bool CheckpointStore::clear_session() {
    if (prefix_.empty()) return false;
    std::error_code ec;
    if (!fs::exists(dir_, ec)) return true;
    for (const auto& p : fs::directory_iterator(dir_, ec)) {
        if (ec) return false;
        const std::string n = p.path().filename().string();
        if (n.rfind(prefix_, 0) == 0 || n.rfind(prefix_ + ".", 0) == 0) {
            fs::remove(p.path(), ec);
            if (ec) return false;
        }
    }
    return true;
}

} // namespace surasaki
