#include "worker_pool.hpp"
#include <system_error>
#include <stdexcept>
namespace surasaki {
WorkerPool::WorkerPool(size_t w,size_t c):wanted_(w?w:1),capacity_(c?c:1){} WorkerPool::~WorkerPool(){stop();}
void WorkerPool::start(){
 std::lock_guard<std::mutex> l(m_);
 if(!workers_.empty())return;
 stopping_=false; paused_=false;
 for(size_t i=0;i<wanted_;++i){
  try { workers_.emplace_back(&WorkerPool::loop,this); }
  catch(const std::system_error&) { break; }
 }
 if(workers_.empty()) throw std::runtime_error("unable to create any worker thread");
}
bool WorkerPool::submit(Job j){std::unique_lock<std::mutex> l(m_); if(stopping_||q_.size()>=capacity_)return false; q_.push_back(std::move(j)); cv_.notify_one(); return true;}
void WorkerPool::pause(){std::lock_guard<std::mutex>l(m_);paused_=true;} void WorkerPool::resume(){std::lock_guard<std::mutex>l(m_);paused_=false;cv_.notify_all();}
void WorkerPool::stop(){ {std::lock_guard<std::mutex>l(m_); if(workers_.empty())return; stopping_=true; paused_=false;} cv_.notify_all(); for(auto&t:workers_)if(t.joinable())t.join(); workers_.clear(); }
void WorkerPool::wait_idle(){std::unique_lock<std::mutex>l(m_);idle_.wait(l,[&]{return q_.empty()&&active_==0;});}
size_t WorkerPool::queue_size()const{std::lock_guard<std::mutex>l(m_);return q_.size();}
void WorkerPool::loop(){for(;;){Job j;{std::unique_lock<std::mutex>l(m_);cv_.wait(l,[&]{return stopping_||(!paused_&&!q_.empty());});if(stopping_&&q_.empty())return;if(paused_)continue;j=std::move(q_.front());q_.pop_front();++active_;}try{j();}catch(...){ }{std::lock_guard<std::mutex>l(m_);--active_;if(q_.empty()&&active_==0)idle_.notify_all();}}}
}
