#include "runtime.hpp"
#include <chrono>
#include <set>

namespace surasaki {

DictionaryMatchJob::DictionaryMatchJob(std::string p, MatchTarget t, RuntimeConfig c)
    : path_(std::move(p)), target_(std::move(t)), cfg_(c),
      pool_(c.workers ? c.workers : 1, c.queue_capacity ? c.queue_capacity : 1) {}

DictionaryMatchJob::~DictionaryMatchJob() {
    stop();
    wait();
}

bool DictionaryMatchJob::start() {
    JobState expected = JobState::Created;
    if (!state_.compare_exchange_strong(expected, JobState::Ready)) return false;
    try {
        source_ = std::make_unique<DictionaryEngine>(path_);
        source_->open();
        total_ = source_->info().records;
        if (cfg_.start_record > total_) throw std::runtime_error("start_record exceeds dictionary record count");
        if (cfg_.start_record != 0 && !source_->seek(cfg_.start_record))
            throw std::runtime_error("failed to seek dictionary to start_record");
        committed_.store(cfg_.start_record, std::memory_order_release);
        {
            std::lock_guard<std::mutex> lock(control_mutex_);
            stopped_ = false;
            paused_ = false;
        }
        state_ = JobState::Running;
        coordinator_ = std::thread(&DictionaryMatchJob::run, this);
        return true;
    } catch (const std::exception& e) {
        std::lock_guard<std::mutex> lock(result_mutex_);
        error_ = e.what();
        state_ = JobState::Failed;
        return false;
    }
}

void DictionaryMatchJob::pause() {
    std::lock_guard<std::mutex> lock(control_mutex_);
    if (state_ == JobState::Running) {
        paused_ = true;
        state_ = JobState::Paused;
    }
}

void DictionaryMatchJob::resume() {
    {
        std::lock_guard<std::mutex> lock(control_mutex_);
        if (state_ != JobState::Paused) return;
        paused_ = false;
        state_ = JobState::Running;
    }
    control_cv_.notify_all();
}

void DictionaryMatchJob::stop() {
    {
        std::lock_guard<std::mutex> lock(control_mutex_);
        stopped_ = true;
        paused_ = false;
        if (state_ == JobState::Running || state_ == JobState::Paused)
            state_ = JobState::Stopped;
    }
    control_cv_.notify_all();
    submit_cv_.notify_all();
    // The coordinator owns the WorkerPool lifetime while a run is active.
    // Calling pool_.stop() here would race with coordinator submissions.
}

void DictionaryMatchJob::wait() {
    if (coordinator_.joinable()) coordinator_.join();
}

std::optional<RuntimeResult> DictionaryMatchJob::result() const {
    std::lock_guard<std::mutex> lock(result_mutex_);
    return result_;
}

std::string DictionaryMatchJob::error() const {
    std::lock_guard<std::mutex> lock(result_mutex_);
    return error_;
}

void DictionaryMatchJob::run() {
    try {
        pool_.start();
        std::atomic<bool> found{false};
        std::atomic<size_t> pending{0};
        std::mutex commit_mutex;
        std::set<uint64_t> completed;
        uint64_t next = cfg_.start_record;
        uint64_t next_commit = cfg_.start_record;

        auto finish = [&](uint64_t idx) {
            {
                std::lock_guard<std::mutex> lock(commit_mutex);
                completed.insert(idx);
                while (completed.erase(next_commit) != 0) ++next_commit;
                committed_.store(next_commit, std::memory_order_release);
            }
            pending.fetch_sub(1, std::memory_order_acq_rel);
            submit_cv_.notify_all();
        };

        for (;;) {
            {
                std::unique_lock<std::mutex> lock(control_mutex_);
                control_cv_.wait(lock, [&] { return stopped_ || !paused_; });
                if (stopped_) break;
            }
            if (found.load(std::memory_order_acquire)) break;

            std::string candidate;
            const uint64_t idx = next;
            if (!source_->next(candidate)) break;

            // Do not allow a single pathological candidate to occupy an
            // unbounded amount of queued work; batch_size is the maximum
            // number of candidates submitted before checking control state.
            pending.fetch_add(1, std::memory_order_acq_rel);
            const bool submitted = pool_.submit(
                [this, idx, candidate = std::move(candidate), &found, &finish]() mutable {
                    if (found.load(std::memory_order_acquire)) {
                        finish(idx);
                        return;
                    }
                    try {
                        if (target_.matches(candidate)) {
                            bool expected = false;
                            if (found.compare_exchange_strong(expected, true,
                                                              std::memory_order_acq_rel)) {
                                std::lock_guard<std::mutex> lock(result_mutex_);
                                result_ = RuntimeResult{true, idx, candidate, {}};
                            }
                        }
                        stats_.processed();
                        if (cfg_.on_progress) {
                            const auto done = stats_.processed_count();
                            const auto interval = cfg_.progress_interval ? cfg_.progress_interval : 1;
                            if ((done % interval) == 0) cfg_.on_progress(committed_.load(std::memory_order_acquire), total_, stats_);
                        }
                    } catch (...) {
                        stats_.error();
                    }
                    finish(idx);
                });

            if (!submitted) {
                pending.fetch_sub(1, std::memory_order_acq_rel);
                submit_cv_.notify_all();
                if (found.load(std::memory_order_acquire)) break;
                std::unique_lock<std::mutex> lock(submit_mutex_);
                submit_cv_.wait_for(lock, std::chrono::milliseconds(2), [&] {
                    return found.load(std::memory_order_acquire) || stopped_ ||
                           pool_.queue_size() < (cfg_.queue_capacity ? cfg_.queue_capacity : 1);
                });
                if (stopped_) break;
                continue;
            }

            ++next;
            const size_t batch = cfg_.batch_size ? cfg_.batch_size : 1;
            if (pending.load(std::memory_order_acquire) >= batch) {
                std::unique_lock<std::mutex> lock(submit_mutex_);
                submit_cv_.wait(lock, [&] {
                    return pending.load(std::memory_order_acquire) < batch ||
                           found.load(std::memory_order_acquire) || stopped_;
                });
            }
            if (found.load(std::memory_order_acquire) || stopped_) break;
        }

        {
            std::unique_lock<std::mutex> lock(submit_mutex_);
            submit_cv_.wait(lock, [&] { return pending.load(std::memory_order_acquire) == 0; });
        }
        pool_.stop();
        if (cfg_.on_progress) {
            cfg_.on_progress(committed_.load(std::memory_order_acquire), total_, stats_);
        }

        if (stopped_) return;
        if (found.load(std::memory_order_acquire)) {
            state_ = JobState::Found;
            return;
        }
        state_ = JobState::Completed;
    } catch (const std::exception& e) {
        pool_.stop();
        {
            std::lock_guard<std::mutex> lock(result_mutex_);
            error_ = e.what();
        }
        state_ = JobState::Failed;
    } catch (...) {
        pool_.stop();
        {
            std::lock_guard<std::mutex> lock(result_mutex_);
            error_ = "unknown runtime error";
        }
        state_ = JobState::Failed;
    }
}

} // namespace surasaki
