#include "crypto_engine.hpp"
#include "secp256k1_pure.hpp"
#include <openssl/evp.h>
#include <openssl/sha.h>
#include <openssl/aes.h>
#include <cstring>
#include <stdexcept>

namespace surasaki {

Bytes sha256(const uint8_t* data, size_t len) {
    Bytes out(SHA256_DIGEST_LENGTH);
    SHA256(data, len, out.data());
    return out;
}

Bytes sha256(const Bytes& data) {
    return sha256(data.data(), data.size());
}

EvpKeyIv evp_bytes_to_key_sha512(const Bytes& password, const Bytes& salt, int count) {
    if (count < 1)
        throw std::runtime_error("nDeriveIterations must be >= 1");
    if (salt.size() != 8)
        throw std::runtime_error("Bitcoin Core salt must be exactly 8 bytes");
    if (password.size() > 248)
        throw std::runtime_error("password too long for EVP engine (max 248 UTF-8 bytes)");

    // OpenSSL EVP_BytesToKey with SHA-512, key=32, iv=16
    // This is the exact function Bitcoin Core uses for nDerivationMethod=0.
    Bytes key(32), iv(16);
    int ret = EVP_BytesToKey(
        EVP_aes_256_cbc(),
        EVP_sha512(),
        salt.data(),
        password.data(),
        static_cast<int>(password.size()),
        count,
        key.data(),
        iv.data()
    );
    if (ret != 32)
        throw std::runtime_error("EVP_BytesToKey failed");

    return {std::move(key), std::move(iv)};
}

Bytes aes256_cbc_decrypt(const Bytes& key, const Bytes& iv, const Bytes& ciphertext) {
    if (key.size() != 32)
        throw std::runtime_error("AES key must be 32 bytes");
    if (iv.size() != 16)
        throw std::runtime_error("AES IV must be 16 bytes");
    if (ciphertext.empty() || (ciphertext.size() % 16) != 0)
        throw std::runtime_error("AES-CBC ciphertext must be non-empty and multiple of 16");

    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    if (!ctx)
        throw std::runtime_error("EVP_CIPHER_CTX_new failed");

    Bytes out(ciphertext.size() + 16);
    int outlen1 = 0, outlen2 = 0;
    bool ok = false;

    if (EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), nullptr, key.data(), iv.data()) == 1 &&
        EVP_DecryptUpdate(ctx, out.data(), &outlen1, ciphertext.data(), static_cast<int>(ciphertext.size())) == 1 &&
        EVP_DecryptFinal_ex(ctx, out.data() + outlen1, &outlen2) == 1) {
        ok = true;
        out.resize(static_cast<size_t>(outlen1 + outlen2));
    }

    EVP_CIPHER_CTX_free(ctx);
    if (!ok)
        throw std::runtime_error("AES-256-CBC decrypt failed (bad padding or key)");
    return out;
}

CheckResult check_wallet_candidate(const std::string& candidate, const WalletConfig& cfg) {
    try {
        Bytes pass(candidate.begin(), candidate.end());
        auto dk = evp_bytes_to_key_sha512(pass, cfg.salt, cfg.iterations);

        Bytes plain_master;
        try {
            plain_master = aes256_cbc_decrypt(dk.key, dk.iv, cfg.mkey_cipher);
        } catch (...) {
            return {CheckStatus::Invalid, "AES-256-CBC padding/decryption failed"};
        }

        if (plain_master.size() != 32)
            return {CheckStatus::Invalid, "Decrypted CMasterKey is not 32 bytes"};

        return validate_ckey(plain_master, cfg.ckey_cipher, cfg.pubkey);
    } catch (const std::exception& e) {
        return {CheckStatus::Unknown, e.what()};
    }
}

bool run_crypto_self_test(bool verbose) {
    int passed = 0;
    int total  = 0;
    auto check = [&](const char* name, bool ok, const std::string& detail = "") {
        ++total;
        if (ok) {
            ++passed;
            if (verbose) log(std::string("✅ ") + name + (detail.empty() ? "" : "  " + detail));
        } else {
            if (verbose) log(std::string("❌ ") + name + (detail.empty() ? "" : "  " + detail));
        }
        return ok;
    };

    // 1. SHA-256("abc")
    {
        auto h = sha256(reinterpret_cast<const uint8_t*>("abc"), 3);
        check("SHA-256(\"abc\")",
              to_hex(h) == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
              to_hex(h));
    }

    // 2. EVP_BytesToKey known-answer (password="test", salt=0001020304050607, count=1)
    // These values match the original JS self-test.
    {
        Bytes pass = {'t','e','s','t'};
        Bytes salt = from_hex("0001020304050607");
        auto dk = evp_bytes_to_key_sha512(pass, salt, 1);
        check("EVP key (test/count=1)",
              to_hex(dk.key) == "9db170135498d3e98bedf0ebcf4fe8fc7b9672a9ce5fc48d1f3ac3dcd4a86243",
              to_hex(dk.key));
        check("EVP IV  (test/count=1)",
              to_hex(dk.iv) == "01ffd38143b572d6f3ec29f776a78b46",
              to_hex(dk.iv));
    }

    // 3. Another EVP vector (self-test / count=3)
    {
        Bytes pass = {'s','e','l','f','-','t','e','s','t'};
        Bytes salt = from_hex("0102030405060708");
        auto dk = evp_bytes_to_key_sha512(pass, salt, 3);
        // We only check that it runs and produces 32+16 bytes; full cross-check with fallback
        // is omitted because we trust OpenSSL.
        check("EVP self-test count=3 size", dk.key.size()==32 && dk.iv.size()==16,
              to_hex(dk.key).substr(0,16) + "…");
    }

    // 4. AES-256-CBC known answer (PKCS#7)
    {
        Bytes key = from_hex("2b7e151628aed2a6abf7158809cf4f3c762e7160f38b4da56a784d9045190cfe");
        Bytes iv  = from_hex("000102030405060708090a0b0c0d0e0f");
        Bytes ct  = from_hex("36341212cfe86d8f4a94bc75d5c1a94ac875b5b710991ca77e7c11ea21791550");
        auto pt = aes256_cbc_decrypt(key, iv, ct);
        check("AES-256-CBC decrypt",
              to_hex(pt) == "6bc1bee22e409f96e93d7e117393172a",
              to_hex(pt));
    }

    // 5. secp256k1 generator point (priv=1)
    {
        Bytes priv(32, 0);
        priv[31] = 1;
        auto comp = derive_pub_hex(priv, true);
        auto uncomp = derive_pub_hex(priv, false);
        check("secp256k1 compressed (priv=1)",
              comp == "0279be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798",
              comp);
        check("secp256k1 uncompressed (priv=1)",
              uncomp.rfind("0479be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798", 0) == 0,
              uncomp.substr(0, 16) + "…");
    }

    // 6. ckey IV rule: first 16 bytes of SHA256(SHA256(pubkey))
    {
        Bytes pub = from_hex("0279be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798");
        auto h1 = sha256(pub);
        auto h2 = sha256(h1);
        Bytes iv(h2.begin(), h2.begin() + 16);
        check("ckey IV derivation",
              to_hex(iv) == "b1cd0a4eb6d1cea5eb288fb4474ac403",
              to_hex(iv));
    }

    if (verbose) {
        log("Crypto self-test: " + std::to_string(passed) + "/" + std::to_string(total) + " passed");
    }
    return passed == total;
}

} // namespace surasaki
