#include "crypto_engine.hpp"
#include "gpu.hpp"
#include <algorithm>
#include <cstring>
#include <dlfcn.h>
#include <limits>
#include <stdexcept>
#include <chrono>

namespace surasaki {
namespace {
using cl_int=int; using cl_uint=unsigned int; using cl_ulong=unsigned long long; using cl_size_t=size_t;
using cl_platform_id=struct _cl_platform_id*; using cl_device_id=struct _cl_device_id*;
using cl_context=struct _cl_context*; using cl_command_queue=struct _cl_command_queue*;
using cl_mem=struct _cl_mem*; using cl_program=struct _cl_program*; using cl_kernel=struct _cl_kernel*;
using cl_event=struct _cl_event*; using cl_bool=cl_uint;
constexpr cl_int CL_SUCCESS=0, CL_DEVICE_TYPE_ALL=-1, CL_DEVICE_TYPE_GPU=4, CL_TRUE=1, CL_FALSE=0;
constexpr cl_int CL_MEM_READ_ONLY=1<<2, CL_MEM_WRITE_ONLY=1<<1;
constexpr cl_int CL_DEVICE_NAME=0x102B, CL_PLATFORM_NAME=0x0902, CL_PLATFORM_VERSION=0x0901;
constexpr cl_int CL_PROGRAM_BUILD_LOG=0x1183;

struct Api {
 void* h=nullptr;
 #define FN(ret,name,args) ret (*name) args=nullptr
 FN(cl_int,clGetPlatformIDs,(cl_uint,cl_platform_id*,cl_uint*));
 FN(cl_int,clGetPlatformInfo,(cl_platform_id,cl_int,size_t,void*,size_t*));
 FN(cl_int,clGetDeviceIDs,(cl_platform_id,cl_ulong,cl_uint,cl_device_id*,cl_uint*));
 FN(cl_int,clGetDeviceInfo,(cl_device_id,cl_int,size_t,void*,size_t*));
 FN(cl_context,clCreateContext,(const void*,cl_uint,const cl_device_id*,void*,void*,cl_int*));
 FN(cl_command_queue,clCreateCommandQueue,(cl_context,cl_device_id,cl_ulong,cl_int*));
 FN(cl_program,clCreateProgramWithSource,(cl_context,cl_uint,const char**,const size_t*,cl_int*));
 FN(cl_int,clBuildProgram,(cl_program,cl_uint,const cl_device_id*,const char*,void*,void*));
 FN(cl_kernel,clCreateKernel,(cl_program,const char*,cl_int*));
 FN(cl_mem,clCreateBuffer,(cl_context,cl_int,size_t,void*,cl_int*));
 FN(cl_int,clSetKernelArg,(cl_kernel,cl_uint,size_t,const void*));
 FN(cl_int,clEnqueueWriteBuffer,(cl_command_queue,cl_mem,cl_bool,size_t,size_t,const void*,cl_uint,const cl_event*,cl_event*));
 FN(cl_int,clEnqueueNDRangeKernel,(cl_command_queue,cl_kernel,cl_uint,const size_t*,const size_t*,const size_t*,cl_uint,const cl_event*,cl_event*));
 FN(cl_int,clEnqueueReadBuffer,(cl_command_queue,cl_mem,cl_bool,size_t,size_t,void*,cl_uint,const cl_event*,cl_event*));
 FN(cl_int,clFinish,(cl_command_queue));
 FN(cl_int,clReleaseMemObject,(cl_mem)); FN(cl_int,clReleaseKernel,(cl_kernel)); FN(cl_int,clReleaseProgram,(cl_program));
 FN(cl_int,clReleaseCommandQueue,(cl_command_queue)); FN(cl_int,clReleaseContext,(cl_context));
 #undef FN
 bool load(){h=dlopen("libOpenCL.so.1",RTLD_LAZY|RTLD_LOCAL); if(!h) h=dlopen("libOpenCL.so",RTLD_LAZY|RTLD_LOCAL); if(!h)return false;
 #define LOAD(x) if(!(x=(decltype(x))dlsym(h,#x))) return false
 LOAD(clGetPlatformIDs);LOAD(clGetPlatformInfo);LOAD(clGetDeviceIDs);LOAD(clGetDeviceInfo);LOAD(clCreateContext);LOAD(clCreateCommandQueue);
 LOAD(clCreateProgramWithSource);LOAD(clBuildProgram);LOAD(clCreateKernel);LOAD(clCreateBuffer);LOAD(clSetKernelArg);LOAD(clEnqueueWriteBuffer);LOAD(clEnqueueNDRangeKernel);LOAD(clEnqueueReadBuffer);LOAD(clFinish);
 LOAD(clReleaseMemObject);LOAD(clReleaseKernel);LOAD(clReleaseProgram);LOAD(clReleaseCommandQueue);LOAD(clReleaseContext); return true; }
 ~Api(){if(h)dlclose(h);} };
#undef LOAD

static std::string info_string(Api& a, cl_platform_id p, cl_int what){size_t n=0;if(a.clGetPlatformInfo(p,what,0,nullptr,&n)!=CL_SUCCESS||!n)return{};std::string s(n,'\0');a.clGetPlatformInfo(p,what,n,s.data(),nullptr);if(!s.empty()&&s.back()=='\0')s.pop_back();return s;}
static std::string dev_string(Api& a, cl_device_id d, cl_int what){size_t n=0;if(a.clGetDeviceInfo(d,what,0,nullptr,&n)!=CL_SUCCESS||!n)return{};std::string s(n,'\0');a.clGetDeviceInfo(d,what,n,s.data(),nullptr);if(!s.empty()&&s.back()=='\0')s.pop_back();return s;}

static const char* kernel_src=R"CLC(
typedef unsigned int u32; typedef unsigned char u8;
constant u32 K[64]={0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};
#define R(x,n) ((x>>n)|(x<<(32-n)))
#define S0(x) (R(x,2)^R(x,13)^R(x,22))
#define S1(x) (R(x,6)^R(x,11)^R(x,25))
#define s0(x) (R(x,7)^R(x,18)^(x>>3))
#define s1(x) (R(x,17)^R(x,19)^(x>>10))
#define CH(x,y,z) ((x&y)^(~x&z))
#define MAJ(x,y,z) ((x&y)^(x&z)^(y&z))
__kernel void sha256_batch(__global const u8* data,__global const u32* offs,__global const u32* lens,__global const u32* target,__global u32* out,const u32 count){size_t id=get_global_id(0);if(id>=count)return;u32 w[64]={0};u32 off=offs[id],len=lens[id];for(u32 i=0;i<len;i++){w[i>>2]|=((u32)data[off+i])<<(24-8*(i&3));}u32 bit=len*8;w[len>>2]|=0x80u<<(24-8*(len&3));w[15]=bit;for(int i=16;i<64;i++)w[i]=s1(w[i-2])+w[i-7]+s0(w[i-15])+w[i-16];u32 a=0x6a09e667,b=0xbb67ae85,c=0x3c6ef372,d=0xa54ff53a,e=0x510e527f,f=0x9b05688c,g=0x1f83d9ab,h=0x5be0cd19;for(int i=0;i<64;i++){u32 t1=h+S1(e)+CH(e,f,g)+K[i]+w[i],t2=S0(a)+MAJ(a,b,c);h=g;g=f;f=e;e=d+t1;d=c;c=b;b=a;a=t1+t2;}u32 H[8]={a+0x6a09e667,b+0xbb67ae85,c+0x3c6ef372,d+0xa54ff53a,e+0x510e527f,f+0x9b05688c,g+0x1f83d9ab,h+0x5be0cd19};out[id]=(H[0]==target[0]&&H[1]==target[1]&&H[2]==target[2]&&H[3]==target[3]&&H[4]==target[4]&&H[5]==target[5]&&H[6]==target[6]&&H[7]==target[7])?1:0;}
)CLC";

static size_t gpu_impl(const std::vector<std::string>& c,const Bytes& target,GpuInfo& inf){
 Api a;if(!a.load()){inf.reason="OpenCL runtime not found";return SIZE_MAX;} if(target.size()!=32){inf.reason="GPU backend supports SHA-256 only";return SIZE_MAX;}
 cl_uint np=0;if(a.clGetPlatformIDs(0,nullptr,&np)!=CL_SUCCESS||np==0){inf.reason="no OpenCL platform";return SIZE_MAX;}std::vector<cl_platform_id> ps(np);a.clGetPlatformIDs(np,ps.data(),nullptr);
 cl_device_id dev=nullptr;cl_platform_id plat=nullptr;for(auto p:ps){cl_uint nd=0;if(a.clGetDeviceIDs(p,CL_DEVICE_TYPE_GPU,0,nullptr,&nd)==CL_SUCCESS&&nd){std::vector<cl_device_id> ds(nd);a.clGetDeviceIDs(p,CL_DEVICE_TYPE_GPU,nd,ds.data(),nullptr);plat=p;dev=ds[0];break;}}
 if(!dev){inf.reason="no OpenCL GPU device";return SIZE_MAX;} inf.available=true;inf.platform=info_string(a,plat,CL_PLATFORM_NAME);inf.version=info_string(a,plat,CL_PLATFORM_VERSION);inf.device=dev_string(a,dev,CL_DEVICE_NAME);
 cl_int err=0;cl_context ctx=a.clCreateContext(nullptr,1,&dev,nullptr,nullptr,&err);if(!ctx||err){inf.reason="OpenCL context creation failed";return SIZE_MAX;}cl_command_queue q=a.clCreateCommandQueue(ctx,dev,0,&err);if(!q||err){a.clReleaseContext(ctx);inf.reason="OpenCL command queue creation failed";return SIZE_MAX;}
 const char* src=kernel_src;size_t slen=std::strlen(src);cl_program prog=a.clCreateProgramWithSource(ctx,1,&src,&slen,&err);if(!prog||err){a.clReleaseCommandQueue(q);a.clReleaseContext(ctx);inf.reason="OpenCL program creation failed";return SIZE_MAX;}err=a.clBuildProgram(prog,1,&dev,nullptr,nullptr,nullptr);if(err){a.clReleaseProgram(prog);a.clReleaseCommandQueue(q);a.clReleaseContext(ctx);inf.reason="OpenCL SHA-256 kernel build failed";return SIZE_MAX;}cl_kernel k=a.clCreateKernel(prog,"sha256_batch",&err);if(!k||err){a.clReleaseProgram(prog);a.clReleaseCommandQueue(q);a.clReleaseContext(ctx);inf.reason="OpenCL kernel creation failed";return SIZE_MAX;}
 const size_t max_len=55; size_t base=0;
 while(base<c.size()){
  size_t n=std::min<size_t>(c.size()-base,8192);
  std::vector<uint8_t> data; std::vector<uint32_t> offs,lens; std::vector<size_t> map;
  data.reserve(n*16); offs.reserve(n); lens.reserve(n); map.reserve(n);
  for(size_t i=0;i<n;i++){
   const auto& v=c[base+i];
   if(v.size()>max_len){ if(sha256(reinterpret_cast<const uint8_t*>(v.data()),v.size())==target){a.clReleaseKernel(k);a.clReleaseProgram(prog);a.clReleaseCommandQueue(q);a.clReleaseContext(ctx);return base+i;} continue; }
   map.push_back(base+i); offs.push_back((uint32_t)data.size()); lens.push_back((uint32_t)v.size()); data.insert(data.end(),v.begin(),v.end());
  }
  if(map.empty()){base+=n;continue;}
  std::vector<uint32_t> tgt(8);for(int i=0;i<8;i++)tgt[i]=(uint32_t(target[i*4])<<24)|(uint32_t(target[i*4+1])<<16)|(uint32_t(target[i*4+2])<<8)|target[i*4+3];
  cl_mem bd=a.clCreateBuffer(ctx,CL_MEM_READ_ONLY,data.size()?data.size():1,nullptr,&err);cl_mem bo=a.clCreateBuffer(ctx,CL_MEM_READ_ONLY,offs.size()*4,nullptr,&err);cl_mem bl=a.clCreateBuffer(ctx,CL_MEM_READ_ONLY,lens.size()*4,nullptr,&err);cl_mem bt=a.clCreateBuffer(ctx,CL_MEM_READ_ONLY,32,nullptr,&err);cl_mem br=a.clCreateBuffer(ctx,CL_MEM_WRITE_ONLY,map.size()*4,nullptr,&err);
  if(err){inf.reason="OpenCL buffer allocation failed";if(bd)a.clReleaseMemObject(bd);if(bo)a.clReleaseMemObject(bo);if(bl)a.clReleaseMemObject(bl);if(bt)a.clReleaseMemObject(bt);if(br)a.clReleaseMemObject(br);break;}
  a.clEnqueueWriteBuffer(q,bd,CL_TRUE,0,data.size()?data.size():1,data.data(),0,nullptr,nullptr);a.clEnqueueWriteBuffer(q,bo,CL_TRUE,0,offs.size()*4,offs.data(),0,nullptr,nullptr);a.clEnqueueWriteBuffer(q,bl,CL_TRUE,0,lens.size()*4,lens.data(),0,nullptr,nullptr);a.clEnqueueWriteBuffer(q,bt,CL_TRUE,0,32,tgt.data(),0,nullptr,nullptr);
  cl_uint count=(cl_uint)map.size();a.clSetKernelArg(k,0,sizeof(bd),&bd);a.clSetKernelArg(k,1,sizeof(bo),&bo);a.clSetKernelArg(k,2,sizeof(bl),&bl);a.clSetKernelArg(k,3,sizeof(bt),&bt);a.clSetKernelArg(k,4,sizeof(br),&br);a.clSetKernelArg(k,5,sizeof(count),&count);size_t g=map.size();
  if(a.clEnqueueNDRangeKernel(q,k,1,nullptr,&g,nullptr,0,nullptr,nullptr)!=CL_SUCCESS||a.clFinish(q)!=CL_SUCCESS){inf.reason="OpenCL kernel execution failed";a.clReleaseMemObject(bd);a.clReleaseMemObject(bo);a.clReleaseMemObject(bl);a.clReleaseMemObject(bt);a.clReleaseMemObject(br);break;}
  std::vector<uint32_t> out(map.size());a.clEnqueueReadBuffer(q,br,CL_TRUE,0,map.size()*4,out.data(),0,nullptr,nullptr);for(size_t i=0;i<map.size();i++)if(out[i]){auto m=map[i];a.clReleaseMemObject(bd);a.clReleaseMemObject(bo);a.clReleaseMemObject(bl);a.clReleaseMemObject(bt);a.clReleaseMemObject(br);a.clReleaseKernel(k);a.clReleaseProgram(prog);a.clReleaseCommandQueue(q);a.clReleaseContext(ctx);return m;}
  a.clReleaseMemObject(bd);a.clReleaseMemObject(bo);a.clReleaseMemObject(bl);a.clReleaseMemObject(bt);a.clReleaseMemObject(br);base+=n;
 }
 a.clReleaseKernel(k);a.clReleaseProgram(prog);a.clReleaseCommandQueue(q);a.clReleaseContext(ctx);return SIZE_MAX;
}
}
GpuInfo detect_gpu(){GpuInfo i;Api a;if(!a.load()){i.reason="OpenCL runtime not found";return i;}cl_uint np=0;if(a.clGetPlatformIDs(0,nullptr,&np)!=CL_SUCCESS||!np){i.reason="no OpenCL platform";return i;}std::vector<cl_platform_id> ps(np);a.clGetPlatformIDs(np,ps.data(),nullptr);for(auto p:ps){cl_uint nd=0;if(a.clGetDeviceIDs(p,CL_DEVICE_TYPE_GPU,0,nullptr,&nd)==CL_SUCCESS&&nd){std::vector<cl_device_id> ds(nd);a.clGetDeviceIDs(p,CL_DEVICE_TYPE_GPU,nd,ds.data(),nullptr);i.available=true;i.platform=info_string(a,p,CL_PLATFORM_NAME);i.version=info_string(a,p,CL_PLATFORM_VERSION);i.device=dev_string(a,ds[0],CL_DEVICE_NAME);return i;}}i.reason="no OpenCL GPU device";return i;}
size_t gpu_sha256_first_match(const std::vector<std::string>& c,const Bytes& t,GpuInfo* out){GpuInfo i;auto r=gpu_impl(c,t,i);if(out)*out=i;return r;}
GpuBenchmarkResult benchmark_gpu_sha256(size_t candidates) {
    GpuBenchmarkResult r;
    if (candidates == 0) candidates = 1;
    GpuInfo gi = detect_gpu();
    r.available = gi.available; r.device = gi.device; r.reason = gi.reason;
    if (!gi.available) return r;
    std::vector<std::string> batch; batch.reserve(candidates);
    for (size_t i=0;i<candidates;++i) batch.push_back("surasaki-gpu-bench-" + std::to_string(i));
    Bytes target(32, 0);
    const auto t0 = std::chrono::steady_clock::now();
    (void)gpu_sha256_first_match(batch, target, &gi);
    r.seconds = std::chrono::duration<double>(std::chrono::steady_clock::now()-t0).count();
    r.candidates = candidates;
    r.candidates_per_second = r.seconds > 0.0 ? static_cast<double>(candidates) / r.seconds : 0.0;
    return r;
}

} // namespace surasaki
