#include "symbolic_runtime.hpp"
#include "worker_pool.hpp"
#include <atomic>
#include <mutex>
#include <condition_variable>
#include <set>
#include <stdexcept>
#include <chrono>
namespace surasaki {
SymbolicRunResult run_symbolic_match(const GeneratorConfig& gc,const MatchTarget& target,const SymbolicRunConfig& cfg){
    // MatchMode::Wallet is fully supported here.
    // target.matches() performs passphrase verification against the loaded wallet context.
    // Works for Exact, Sha256 and Wallet modes through the generic MatchTarget interface.
    SymbolicGenerator g(gc);
    if(cfg.start && !g.seek(BigInt(cfg.start))) throw std::runtime_error("symbolic start exceeds search space");
    const BigInt total=g.total();
    const size_t workers=cfg.workers?cfg.workers:1, batch=cfg.batch_size?cfg.batch_size:1;
    WorkerPool pool(workers,std::max<size_t>(batch*2,2)); pool.start(); Statistics stats;
    std::atomic<bool> found{false};
    std::mutex m, cv_m; std::condition_variable cv;
    size_t pending=0; std::set<uint64_t> done; uint64_t next_commit=cfg.start, ordinal=cfg.start;
    SymbolicRunResult result;
    auto submit_one = [&](uint64_t idx, std::string candidate)->bool {
        auto shared_candidate = std::make_shared<std::string>(std::move(candidate));
        for (;;) {
            if(found.load(std::memory_order_acquire)) return false;
            std::unique_lock<std::mutex> guard(cv_m);
            ++pending;
            const bool accepted = pool.submit([&,idx,shared_candidate]() mutable {
                const std::string& c = *shared_candidate;
                if(!found.load(std::memory_order_acquire)) {
                    try {
                        if(target.matches(c)) {
                            bool expected=false;
                            if(found.compare_exchange_strong(expected,true,std::memory_order_acq_rel)) {
                                std::lock_guard<std::mutex> l(m);
                                result.found=true; result.index=idx; result.candidate=c;
                            }
                        }
                        stats.processed();
                    } catch(...) { stats.error(); }
                }
                {
                    std::lock_guard<std::mutex> l(cv_m);
                    done.insert(idx);
                    while(done.erase(next_commit)!=0) ++next_commit;
                    if(pending>0) --pending;
                }
                cv.notify_all();
            });
            if (accepted) { guard.unlock(); return true; }
            --pending;
            if(found.load(std::memory_order_acquire)) return false;
            cv.wait_for(guard,std::chrono::milliseconds(2),[&]{return found.load(std::memory_order_acquire) || pending<batch;});
        }
    };
    for(;;){
        if(found.load(std::memory_order_acquire)) break;
        if(cfg.limit && stats.processed_count() >= cfg.limit) break;
        auto v=g.next(); if(!v) break;
        const uint64_t idx=ordinal++;
        if(!submit_one(idx,std::move(*v))) break;
        {
            std::unique_lock<std::mutex> l(cv_m);
            if(pending>=batch) cv.wait(l,[&]{return pending<batch || found.load(std::memory_order_acquire);});
        }
        if(cfg.on_progress) cfg.on_progress(next_commit,total,stats);
    }
    { std::unique_lock<std::mutex> l(cv_m); cv.wait(l,[&]{return pending==0;}); }
    pool.stop(); result.processed=stats.processed_count(); return result;
}
} // namespace surasaki
